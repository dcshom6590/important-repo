'use strict';

/**
 * field-name controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::field-name.field-name');
