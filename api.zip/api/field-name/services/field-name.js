'use strict';

/**
 * field-name service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::field-name.field-name');
