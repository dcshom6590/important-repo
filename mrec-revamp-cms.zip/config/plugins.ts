export default () => ({graphql: {
    enabled: true,
    config: {
      endpoint: "/graphql",
      shadowCRUD: true,   // IMPORTANT
      playgroundAlways: true,
      depthLimit: 20,
      amountLimit: 100,
    },
  },
});
