import puppeteer from "puppeteer";
import fs from "fs";
import Mustache from "mustache";

const browser = await puppeteer.launch();
const page = await browser.newPage();

const template = fs.readFileSync("demo.html", "utf-8");

const rendered = Mustache.render(template, {
  fullName: "Mr. Raj Dutta",
  reportDate: "08-Oct-2025",
});

await page.setContent(rendered, {
  waitUntil: "networkidle0",
});

const pdfBuffer = await page.pdf({
  format: "A4",
  printBackground: true,
});

fs.writeFileSync("portfolio-report.pdf", pdfBuffer);

await browser.close();
