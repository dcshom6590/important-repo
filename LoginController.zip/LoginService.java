package com.demo.demo;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.demo.demo.dto.ClientDto;
import com.demo.demo.dto.PolicyDto;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class LoginService {
    
    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final String API_TOKEN = "eyJraWQiOiJnRm5IUTVDdm9taUFmU0lmRjJwNGF6TkFQYTVpS0dUeGJmdW15Ym9UZFUwPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiI0dWhuODU5bzd0MnJlMG1pMGxxOHE1anZyZiIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiYWRtaW5cL3dyaXRlIGFkbWluXC9yZWFkIiwiYXV0aF90aW1lIjoxNzc1NzM0NzUyLCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAuYXAtc291dGgtMS5hbWF6b25hd3MuY29tXC9hcC1zb3V0aC0xX2tMVkxMT2hGRCIsImV4cCI6MTc3NTczODM1MiwiaWF0IjoxNzc1NzM0NzUyLCJ2ZXJzaW9uIjoyLCJqdGkiOiJhYWI5ODhlZi0xNWNjLTQwNTYtYjBhZS0zZTA5OTQ0MDhmZDUiLCJjbGllbnRfaWQiOiI0dWhuODU5bzd0MnJlMG1pMGxxOHE1anZyZiJ9.fHZIHUREdSCTamTH1x3e9ZnqHYWr0J0hEqoU5967qImDS7ZbXb9IU4oGoGBXOXE9LsGCt1bbhsibKAzldNFSJwrslHvE-gs15eAZVxLEBXOqenA0t2dqEj2IQFgpcYXFgDXEhsy1eyKfa_hnPF2HwNRwxxIS0wttf_GOM15tK9eYEjcp6hIe_WR-JRp3eoSdaCrAd1S1iyBOUQBM5HiB1b6QYo_fvusd0CGVsfcqz3_vX8uhbS9kZAorM2bUWrzR_z7eXqaPtLUOyTGgiSzWeT8fCLxS-9tv8JdwuIOwpuNNvegDU-BPVZeARON63P8mhC5RAy7Vdjg149_nuOe3Lw";
    
    public PolicyDto getPolicyDetails(String polId) {
        try {
            String url = "https://gatewayclouduat.maxlifeinsurance.com/uat/policy360/getpolicydetails";
            
            // Set headers
            HttpHeaders headers = new HttpHeaders();
            headers.set("x-api-key", "X40OMfAKAh3Fz62CNl6FUDheG3mCgum2heDrLHk2");
            headers.set("x-apigw-api-id", "puaewiy985");
            headers.set("Authorization", "Bearer " + API_TOKEN);
            headers.set("APPID", "CLAIMSWEBSITEJOURNEY");
            headers.set("Content-Type", "application/json");
            
            // Build request body
            Map<String, Object> requestBody = new HashMap<>();
            Map<String, Object> request = new HashMap<>();
            Map<String, Object> header = new HashMap<>();
            header.put("soaCorrelationId", "2841");
            header.put("soaAppId", "CLAIMSWEBSITEJOURNEY");
            
            Map<String, Object> payload = new HashMap<>();
            payload.put("policyNo", polId);
            
            List<Map<String, String>> services = Arrays.asList(
                Map.of("serviceName", "policyClientRelationship", "clientRole", "T"),
                Map.of("serviceName", "policyClientRelationship", "clientRole", "I"),
                Map.of("serviceName", "nomineeDetails"),
                Map.of("serviceName", "policyBasicDetails"),
                Map.of("serviceName", "coverageDetails")
            );
            payload.put("services", services);
            
            request.put("header", header);
            request.put("payload", payload);
            requestBody.put("request", request);
            
            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);
            
            ResponseEntity<PolicyDto> response = restTemplate.exchange(
                url,
                HttpMethod.POST,
                entity,
                PolicyDto.class
            );
            
            return response.getBody();
        } catch (Exception e) {
            throw new RuntimeException("Error calling policy API", e);
        }
    }
    
    public ClientDto getClientDetails(String clientId) {
        try {
            String url = "https://gatewayclouduat.maxlifeinsurance.com/uat/getcustomerdetails";
            
            // Set headers
            HttpHeaders headers = new HttpHeaders();
            headers.set("x-api-key", "X40OMfAKAh3Fz62CNl6FUDheG3mCgum2heDrLHk2");
            headers.set("x-apigw-api-id", "puaewiy985");
            headers.set("Authorization", "Bearer " + API_TOKEN);
            headers.set("APPID", "CLAIMSWEBSITEJOURNEY");
            headers.set("Content-Type", "application/json");
            
            // Build request body
            Map<String, Object> requestBody = new HashMap<>();
            Map<String, Object> request = new HashMap<>();
            Map<String, Object> header = new HashMap<>();
            header.put("soaCorrelationId", "11827g07t");
            header.put("soaAppId", "CLAIMSWEBSITEJOURNEY");
            
            Map<String, Object> payload = new HashMap<>();
            payload.put("clientId", clientId);
            
            List<Map<String, String>> services = Arrays.asList(
                Map.of("serviceName", "baseAddDetail"),
                Map.of("serviceName", "personalDetail"),
                Map.of("serviceName", "contactDetail"),
                Map.of("serviceName", "identifiableInfo"),
                Map.of("serviceName", "clientPolicyRelationship")
            );
            payload.put("services", services);
            
            request.put("header", header);
            request.put("payload", payload);
            requestBody.put("request", request);
            
            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);
            
            ResponseEntity<ClientDto> response = restTemplate.exchange(
                url,
                HttpMethod.POST,
                entity,
                ClientDto.class
            );
            
            return response.getBody();
        } catch (Exception e) {
            throw new RuntimeException("Error calling client API", e);
        }
    }
    
    public void validatePolicy(PolicyDto policy) {
        PolicyDto.Payload payload = policy.getResponse().getPayload();
        
        // VALIDATION 1: Check for Joint Life Policy using coverageDetails
        List<String> jointLifePlanCodes = Arrays.asList(
            "IAJ", "IAJC", "IAJR", "IAJRC", "TDAJ", "TDAJC", "IALJ", "IALJC", "IALJRP", "IALRJC",
            "TIAJRC", "TIAJR", "TIAGJ", "TIAGJF", "TIAGJR", "TDAJN", "TDAJNC", "TSPJS", "TSPJR",
            "TSPJL", "TSPJ6", "TSRJS", "TSRJR", "TSRJL", "TSRJ6", "TIRJ", "TDRJ", "TIRJR", "TDRJR",
            "TDRJN", "TDRJNR", "TIGRJ", "TIGRJR", "TDGRJR", "TPFDG2", "TPFDG1", "TSFDG2", "TSFDG1",
            "TSWRW2", "TSWRW1", "TSWPW1", "TSWPW2", "TIRJFR", "TIRJF", "TIRJRF", "TIRJRP", "TDGRJ"
        );
        
        if (payload.getCoverageDetails() != null) {
            boolean isJointLife = payload.getCoverageDetails().stream()
                .anyMatch(coverage -> {
                    String planCode = coverage.getCvgPlanIdCd();
                    return planCode != null && jointLifePlanCodes.contains(planCode.trim());
                });
            
            if (isJointLife) {
                throw new RuntimeException("Joint Life Policy not allowed");
            }
        }
        
        // VALIDATION 2: Check for Life Insured via policyClientRelationship
        List<com.demo.demo.dto.PolicyClientRelationshipDto> policyClientRelationship = 
            payload.getPolicyClientRelationship();
        
        if (policyClientRelationship != null) {
            long insuredCount = policyClientRelationship.stream()
                .filter(relation -> {
                    String relatnType = relation.getRelatnType();
                    return relatnType != null && "I".equals(relatnType.trim());
                })
                .count();
            
            if (insuredCount == 0) {
                throw new RuntimeException("At least 1 Life Insured is required");
            }
        } else {
            throw new RuntimeException("At least 1 Life Insured is required");
        }
        
        // VALIDATION 3: Check for Assignees using policyAssigneeId from policyBasicDetails
        if (payload.getPolicyBasicDetails() != null) {
            String policyAssigneeId = payload.getPolicyBasicDetails().getPolicyAssigneeId();
            if (policyAssigneeId != null && !policyAssigneeId.trim().isBlank()) {
                throw new RuntimeException("Assignee not allowed");
            }
        }
    }
}