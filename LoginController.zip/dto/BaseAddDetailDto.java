package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseAddDetailDto {
    private String addrLine1;
    private String addrLine2;
    private String addrLine3;
    private String city;
    private String state;
    private String pinCode;
    private String country;
    private String stateCd;
    private String addrType;
}
