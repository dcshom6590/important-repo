package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContactDetailDto {
    private String emalId;
    private String faxNum;
    private String mobNum;
    private String lastContactNum;
    private String dncStatus;
    private String dndStatus;
    private String currentLandline1;
    private String permanentLandline1;
    private String workLandline1;
    private String currentLandline2;
    private String permanentLandline2;
    private String workLandline2;
    private String greenMailFlag;
    private String lastEmail;
    private String lastMobile;
    private String phone1;
    private String phone2;
    private String addresslastupdateddate;
    private String altMobNum;
    private String emailLastUpdatedDate;
    private String mobileLastUpdatedDate;
}
