package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyDto {
    private Response response;
    
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Response {
        private Header header;
        private MsgInfo msgInfo;
        private Payload payload;
    }
    
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Header {
        private String soaCorrelationId;
        private String soaAppId;
    }
    
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class MsgInfo {
        private String msgCode;
        private String msg;
        private String msgDescription;
    }
    
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Payload {
        private String policyNo;
        private String planName;
        private String planType;
        private String policyStatusCode;
        private String policyStatusDesc;
        private String policyHolderName;
        private String mobileNo;
        private String dob;
        private String emailID;
        private PolicyBasicDetailsDto policyBasicDetails;
        private List<CoverageDetailsDto> coverageDetails;
        private List<PolicyClientRelationshipDto> policyClientRelationship;
        private NomineeDetailsDto nomineeDetails;
    }
}
