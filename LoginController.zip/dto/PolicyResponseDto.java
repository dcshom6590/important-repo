package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PolicyResponseDto {
    @JsonProperty("policyNo")
    private String policyNo;
    
    @JsonProperty("clientID")
    private String clientID;
    
    @JsonProperty("LADOB")
    private String ladob;
    
    @JsonProperty("Salutation")
    private String salutation;
    
    @JsonProperty("InsuredFirst_name")
    private String insuredFirstName;
    
    @JsonProperty("InsuredLast_name")
    private String insuredLastName;
    
    @JsonProperty("Gender")
    private String gender;
    
    @JsonProperty("custRole")
    private String custRole;
    
    @JsonProperty("productname")
    private String productName;
    
    @JsonProperty("Product_code")
    private String productCode;
    
    @JsonProperty("mobile_no")
    private String mobileNo;
    
    @JsonProperty("HNI_flag")
    private String hniFlag;
    
    @JsonProperty("legalFlag")
    private String legalFlag;
    
    @JsonProperty("ATRFlag")
    private String atrFlag;
    
    @JsonProperty("PolicyIssueDate")
    private String policyIssueDate;
    
    @JsonProperty("PaidtoDate")
    private String paidtoDate;
    
    @JsonProperty("PolicyDuration")
    private String policyDuration;
    
    @JsonProperty("PremiumMode")
    private String premiumMode;
    
    @JsonProperty("GracePeriod")
    private String gracePeriod;
    
    @JsonProperty("PolicyStatus")
    private String policyStatus;
}
