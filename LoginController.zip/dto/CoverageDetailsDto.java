package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CoverageDetailsDto {
    private String cvgNum;
    private String cvgPlanIdCd;
    private String cvgPlanIdDesc;
    private String coverageStatusCd;
    private String cvgFaceAmt;
    private String cvgDutyAmt;
    private String coverageModelPrem;
    private String cvgBasicFaceAmt;
    private String cvgUwgFrcnCd;
    private String cvgActTypCd;
    private String cvgAppRevDt;
    private String cvgMatXpryDt;
    private String cvgIssEffDt;
    private String origPlanIdCd;
    private String cvgRateAge;
    private String cvgFePremAmt;
    private String cvgParCd;
    private String cvgStatEffDt;
    private String premChngAgeDur;
    private String premChngeDtCd;
    private String ulrcvgYn;
    private String ulpcvgYn;
    private String riderServTax;
    private String noOfCoverage;
    private String cvgStatusChangeDt;
    private String coverageStatusDesc;
    private String cvgUwgFrcnDesc;
    private String cvgActTypDesc;
    private String origPlanIdDesc;
    private String riderTerm;
    private String stgstTax;
    private String riderFlg;
    private String zeroCovergeFaceAmt;
    private String riderAnnualPremium;
    private String cvgUwdcnCd;
    private String loading;
    private String cvgSumInsAmt;
    private String deathBenefit;
    private String covLapseReasonCd;
    private String covLapseReasonDesc;
    private String coverageMultiple;
    private String feeTypeCoverMultiple;
    private String productTypeRider;
    private String riskClass;
    private String customerDiscount;
    private String premiumBreakOption;
    private String deathBenefitOption;
    private String riderPremium;
    private String riderInbuiltIdentifier;
}
