package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PayerDetailDto {
    private String policyNo;
    private String cvgNum;
    private String planName;
    private String sumAssured;
    private String planCode;
    private String rcdCd;
    private String lastPremiumPaidDate;
    private String lastPremiumDueDate;
    private String cvgStatus;
    private String relationship;
    private String modalPremium;
}
