package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class NomineeDto {
    @JsonProperty("PolicyNo")
    private String policyNo;
    
    @JsonProperty("LastNomineeChangeDate")
    private String lastNomineeChangeDate;
    
    @JsonProperty("ClientID")
    private String clientID;
    
    @JsonProperty("Salutation")
    private String salutation;
    
    @JsonProperty("FirstName")
    private String firstName;
    
    @JsonProperty("LastName")
    private String lastName;
    
    @JsonProperty("DOB")
    private String dob;
    
    @JsonProperty("Age")
    private String age;
    
    @JsonProperty("RelationshipwithInsured")
    private String relationshipWithInsured;
    
    @JsonProperty("Gender")
    private String gender;
    
    @JsonProperty("Nationality")
    private String nationality;
    
    @JsonProperty("HouseNo_AptName_Society")
    private String houseNoAptNameSociety;
    
    @JsonProperty("Road_Area_Sector")
    private String roadAreaSector;
    
    @JsonProperty("Landmark")
    private String landmark;
    
    @JsonProperty("Village_Town_City_District")
    private String villageTownCityDistrict;
    
    @JsonProperty("Country")
    private String country;
    
    @JsonProperty("State_UT")
    private String stateUT;
    
    @JsonProperty("Pincode")
    private String pincode;
    
    @JsonProperty("ContactNumber")
    private String contactNumber;
    
    @JsonProperty("Email")
    private String email;
    
    @JsonProperty("shareperfloat")
    private String sharePerFloat;
    
    @JsonProperty("amount_n")
    private String amountN;
    
    @JsonProperty("MaritalStatus")
    private String maritalStatus;
    
    @JsonProperty("PANNo")
    private String panNo;
    
    @JsonProperty("NameasperNSDL")
    private String nameAsPerNSDL;
    
    @JsonProperty("Status")
    private String status;
    
    @JsonProperty("PANLinked")
    private String panLinked;
    
    @JsonProperty("mobileno_cust")
    private String mobileNoCust;
    
    @JsonProperty("AadharNo")
    private String aadharNo;
    
    @JsonProperty("VoterIDCard")
    private String voterIDCard;
    
    @JsonProperty("Passport")
    private String passport;
    
    @JsonProperty("DeathBenefitOption")
    private String deathBenefitOption;
    
    @JsonProperty("amlStatus")
    private String amlStatus;
    
    @JsonProperty("Nomineecore_chk")
    private String nomineeCoreChk;
    
    @JsonProperty("SCREENINGID")
    private String screeningID;
    
    @JsonProperty("state_UT_count")
    private String stateUTCount;
    
    @JsonProperty("BeneficiaryType")
    private String beneficiaryType;
    
    @JsonProperty("NSDLCheck")
    private String nsdlCheck;
    
    @JsonProperty("PANExist")
    private String panExist;
}
