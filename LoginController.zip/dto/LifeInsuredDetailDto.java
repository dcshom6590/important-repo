package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class LifeInsuredDetailDto {
    private String insrdCliId;
    private String insuredCliCvg;
    private String uwUserId;
    private String lifeInsuredName;
    private String lifeInsuredDob;
}
