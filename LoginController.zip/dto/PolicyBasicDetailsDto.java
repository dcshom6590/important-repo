package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyBasicDetailsDto {
    @JsonProperty("policyBasePlanIdCd")
    private String policyBasePlanIdCd;
    
    @JsonProperty("policyBasePlanIdDesc")
    private String policyBasePlanIdDesc;
    
    @JsonProperty("policyPmtTerm")
    private String policyPmtTerm;
    
    @JsonProperty("policyIssueDt")
    private String policyIssueDt;
    
    @JsonProperty("policyPtToDtNum")
    private String policyPtToDtNum;
    
    @JsonProperty("billingFreqDesc")
    private String billingFreqDesc;
    
    @JsonProperty("policyAssigneeId")
    private String policyAssigneeId;
}
