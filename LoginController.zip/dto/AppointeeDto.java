package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class AppointeeDto {
    @JsonProperty("policyno")
    private String policyNo;
    
    @JsonProperty("clientID")
    private String clientID;
    
    @JsonProperty("Salutation")
    private String salutation;
    
    @JsonProperty("firstName")
    private String firstName;
    
    @JsonProperty("lastName")
    private String lastName;
    
    @JsonProperty("dob")
    private String dob;
    
    @JsonProperty("age")
    private String age;
    
    @JsonProperty("relnWithProposer")
    private String relnWithProposer;
    
    @JsonProperty("relnWithNominee")
    private String relnWithNominee;
    
    @JsonProperty("gender")
    private String gender;
    
    @JsonProperty("Nationality")
    private String nationality;
    
    @JsonProperty("houseno")
    private String houseno;
    
    @JsonProperty("roadarea")
    private String roadarea;
    
    @JsonProperty("landmark")
    private String landmark;
    
    @JsonProperty("village")
    private String village;
    
    @JsonProperty("country")
    private String country;
    
    @JsonProperty("state")
    private String state;
    
    @JsonProperty("zipCode")
    private String zipCode;
    
    @JsonProperty("appContactNo")
    private String appContactNo;
    
    @JsonProperty("email")
    private String email;
    
    @JsonProperty("percentProceed")
    private String percentProceed;
    
    @JsonProperty("Amount")
    private String amount;
    
    @JsonProperty("maritalStatus")
    private String maritalStatus;
    
    @JsonProperty("pan")
    private String pan;
    
    @JsonProperty("nameAsPerNSDL")
    private String nameAsPerNSDL;
    
    @JsonProperty("Status")
    private String status;
    
    @JsonProperty("PANlink")
    private String panLink;
    
    @JsonProperty("mobileno_cust")
    private String mobileNoCust;
    
    @JsonProperty("aadharNo")
    private String aadharNo;
    
    @JsonProperty("voterid")
    private String voterId;
    
    @JsonProperty("passport")
    private String passport;
    
    @JsonProperty("Appointeecore_chk")
    private String appointeeCoreChk;
    
    @JsonProperty("Amlstatus")
    private String amlStatus;
    
    @JsonProperty("ScreeningID")
    private String screeningID;
}
