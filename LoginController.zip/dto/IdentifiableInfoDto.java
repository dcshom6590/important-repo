package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class IdentifiableInfoDto {
    private String idProof;
    private String idenPrfNum;
    private String panNum;
    private String panUpdateDt;
    private String adharCard;
    private String idProofType;
    private String idProofVal;
    private String idProofUpdateDt;
    private String validTill;
    private String panSubmittedInd;
    private String panValidInd;
    private String aadhaarNum;
    private String aadhaarAuthInd;
    private String panAadhaarInd;
    private String panAadhaarLinked;
    private String passport;
    private String identificationProof;
    private String uid;
    private String cliIdProofTyp;
    private String cliProofNum;
    private String cliExistingKyc;
    private String cliProofExpryDt;
    private String cliKycComplnDt;
    private String cliKycComplnInd;
    private String drivingLicense;
    private String ckycNumber;
    private String voterId;
    private String abhaNumber;
}
