package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class RiderDto {
    @JsonProperty("PolicyNo")
    private String policyNo;
    
    @JsonProperty("ProductName")
    private String productName;
    
    @JsonProperty("PlanCode")
    private String planCode;
    
    @JsonProperty("CoverageStatus")
    private String coverageStatus;
    
    @JsonProperty("Term")
    private String term;
    
    @JsonProperty("PremiumTerm")
    private String premiumTerm;
    
    @JsonProperty("MaturityExpiryDate")
    private String maturityExpiryDate;
    
    @JsonProperty("SumAssured")
    private String sumAssured;
    
    @JsonProperty("Admissible_Non_Admissible")
    private String admissibleNonAdmissible;
    
    @JsonProperty("PolicyIssueDate")
    private String policyIssueDate;
    
    @JsonProperty("PremiumMode")
    private String premiumMode;
    
    @JsonProperty("PaidToDate")
    private String paidToDate;
    
    @JsonProperty("CoverageNo")
    private String coverageNo;
    
    @JsonProperty("Coverage_EffDt")
    private String coverageEffDt;
}
