package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PolicyClientRelationshipDto {
    private String clientID;
    private String roleEfftDt;
    private String relatnReason;
    private String relatnType;
    private String prcntShareOfNom;
    private String prefAddrCode;
    private String relatnCat;
    private String nomineeCliId;
    private String polNomineeAccSlct;
    private String polOwnerAccSlct;
    private String polAssgnTypeCd;
    private String polAssgnType;
    private String nomineeGender;
    private String tusteeCliId;
}
