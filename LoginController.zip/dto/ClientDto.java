package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientDto {
    private Response response;
    
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Response {
        private Header header;
        private MsgInfo msgInfo;
        private Payload payload;
    }
    
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Header {
        private String soaCorrelationId;
        private String soaAppId;
    }
    
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class MsgInfo {
        private String msgCode;
        private String msg;
        private String msgDescription;
    }
    
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Payload {
        private List<ContactDetailDto> contactDetail;
        private IdentifiableInfoDto identifiableInfo;
        private PersonalDetailDto personalDetail;
        private List<ClientPolicyRelationshipDto> clientPolicyRelationship;
        private List<PayerDetailDto> payerdtls;
        private List<BaseAddDetailDto> baseAddDetail;
    }
}
