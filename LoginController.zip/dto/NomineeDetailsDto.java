package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class NomineeDetailsDto {
    private String policyOwnerId;
    private String policyHolderName;
    private String mobileNo;
    private String dob;
    private String emailID;
    private String appointeeClientID;
    private String appointeeName;
    private String appointeeDob;
    private List<NomineeDto> nominees;
    
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class NomineeDto {
        private String nomineeClientID;
        private String nomineeName;
        private String percentageShare;
        private String nomineeRelation;
        private String nomineeDob;
    }
}
