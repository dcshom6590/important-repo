package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientPolicyRelationshipDto {
    private String polId;
    private String cliId;
    private String relationship;
    private String relationshipDesc;
    private String dateOfCommencement;
    private String cvgNum;
    private String polStatus;
    private String policyNumber;
    private String policyStatus;
    private String policyStatusDesc;
    private String productTypeDesc;
    private String planName;
    private String lastPremiumDueDate;
    private String lastPremiumPaidDate;
    private String sumAssured;
    private String productCode;
    private String policyBasePlanIdCd;
    private String policyBasePlanIdDesc;
    private String billingFreqDesc;
    private String cliFirstPolIssueDate;
    private String polDueDate;
    private String policyPmtTerm;
}
