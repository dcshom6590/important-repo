package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;

@Data
public class LoginResponseDto {
    private List<NomineeDto> nominees;
    private List<AppointeeDto> appointee;
    private List<RiderDto> riders;
    private List<PolicyResponseDto> policies;
    private PolicyDetails policyDetails;
    
    @Data
    public static class PolicyDetails {
        @JsonProperty("ATRFlag")
        private String atrFlag;
        
        @JsonProperty("ClientID")
        private String clientID;
        
        @JsonProperty("CustomerRole")
        private String customerRole;
        
        @JsonProperty("EffectiveDateofCoverage")
        private String effectiveDateofCoverage;
        
        @JsonProperty("Father_Spouse")
        private String fatherSpouse;
        
        @JsonProperty("Gender")
        private String gender;
        
        @JsonProperty("InsuredFirstName")
        private String insuredFirstName;
        
        @JsonProperty("InsuredLastName")
        private String insuredLastName;
        
        @JsonProperty("JointLifeFlag")
        private String jointLifeFlag;
        
        @JsonProperty("LA_DOB")
        private String laDob;
        
        @JsonProperty("LifeAssuredPANNumber")
        private String lifeAssuredPANNumber;
        
        @JsonProperty("MobileNo")
        private String mobileNo;
        
        @JsonProperty("PanNo")
        private String panNo;
        
        @JsonProperty("PolicyNo")
        private String policyNo;
        
      
        @JsonProperty("ProductCode")
        private String productCode;
        
        @JsonProperty("ProductName")
        private String productName;
        
        @JsonProperty("Salutation")
        private String salutation;
        
        @JsonProperty("age")
        private int age;
        
        @JsonProperty("sub_lob")
        private String subLob;
    }
}
