package com.demo.demo.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PersonalDetailDto {
    private String title;
    private String firstName;
    private String middleName;
    private String lastName;
    private String occupation;
    private String genderCd;
    private String fatherOrSpouseName;
    private String maritalStatus;
    private String weightInformation;
    private String isSmoker;
    private String isDobProofGiven;
    private String proofDobSubmit;
    private String dob;
    private String incomeSegment;
    private String actualIncome;
    private String genderDesc;
    private String nationality;
    private String education;
    private String organizationName;
    private String preferredLanguage;
    private String atrFlag;
    private String clientNameChangeDate;
}
