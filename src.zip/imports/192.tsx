import imgDone1 from "figma:asset/3b9a9fcae143de986e2f5dcec41fab21a103cee4.png";

function NavigationHeaders() {
  return (
    <div className="bg-[#143a72] content-stretch flex gap-[8px] items-center max-w-[440px] min-h-[64px] min-w-[320px] px-[16px] py-[12px] relative shrink-0 w-[360px]" data-name="Navigation/Headers">
      <div aria-hidden="true" className="absolute border-[rgba(232,235,241,0.2)] border-b border-solid inset-0 pointer-events-none shadow-[0px_4px_12px_0px_rgba(144,164,202,0.2)]" />
      <div className="flex flex-[1_0_0] flex-col font-['Noto_Sans:Regular',sans-serif] justify-center leading-[0] min-h-px min-w-px not-italic relative text-[13px] text-white">
        <p className="leading-[normal] whitespace-pre-wrap">Verification</p>
      </div>
    </div>
  );
}

function MessageContainer() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center leading-[0] not-italic relative shrink-0 text-center w-[310px]" data-name="Message Container">
      <div className="flex flex-col font-['Lato:Regular',sans-serif] justify-center relative shrink-0 text-[#171a21] text-[25px] tracking-[-0.04px] whitespace-nowrap">
        <p className="leading-[normal]">
          Mobile number
          <br aria-hidden="true" />
          authenticated!
        </p>
      </div>
      <div className="flex flex-col font-['Noto_Sans:Regular',sans-serif] justify-center relative shrink-0 text-[#505662] text-[16px] w-[274px]">
        <p className="leading-[normal] whitespace-pre-wrap">All future communications will be shared on this number</p>
      </div>
    </div>
  );
}

function FormSection() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-center justify-center relative shrink-0" data-name="Form Section">
      <div className="relative shrink-0 size-[80px]" data-name="done 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgDone1} />
      </div>
      <MessageContainer />
    </div>
  );
}

function FormContainer() {
  return (
    <div className="content-stretch flex flex-col items-start pb-[40px] pt-[70px] relative shrink-0" data-name="Form Container">
      <FormSection />
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[160px] items-center overflow-clip relative rounded-[16px] size-full" data-name="192">
      <NavigationHeaders />
      <FormContainer />
    </div>
  );
}