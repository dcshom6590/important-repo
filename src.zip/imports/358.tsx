import svgPaths from "./svg-oxcu6xrn6e";

function NavigationHeaders() {
  return (
    <div className="bg-[#143a72] content-stretch flex gap-[8px] items-center max-w-[440px] min-h-[64px] min-w-[320px] px-[16px] py-[12px] relative shrink-0 w-[360px]" data-name="Navigation/Headers">
      <div aria-hidden="true" className="absolute border-[rgba(232,235,241,0.2)] border-b border-solid inset-0 pointer-events-none shadow-[0px_4px_12px_0px_rgba(144,164,202,0.2)]" />
      <div className="flex flex-[1_0_0] flex-col font-['Noto_Sans:Regular',sans-serif] justify-center leading-[0] min-h-px min-w-px not-italic relative text-[13px] text-white">
        <p className="leading-[normal] whitespace-pre-wrap">Verification</p>
      </div>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[9.38%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52 52">
        <g id="Group">
          <path d={svgPaths.pd18ca00} fill="var(--fill-0, #E13B36)" id="Vector" />
          <path d={svgPaths.p371671b0} fill="var(--fill-0, #D1302E)" id="Vector_2" />
          <path d={svgPaths.p3264f00} fill="var(--fill-0, #F2F2F2)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function Failed() {
  return (
    <div className="overflow-clip relative shrink-0 size-[64px]" data-name="failed 1">
      <Group />
    </div>
  );
}

function MessageContainer() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center leading-[0] not-italic relative shrink-0 text-center w-[310px]" data-name="Message Container">
      <div className="flex flex-col font-['Lato:Regular',sans-serif] justify-center relative shrink-0 text-[#171a21] text-[25px] tracking-[-0.04px] whitespace-nowrap">
        <p className="leading-[normal]">
          Mobile number
          <br aria-hidden="true" />
          unable to authenticate
        </p>
      </div>
      <div className="flex flex-col font-['Noto_Sans:Regular',sans-serif] justify-center relative shrink-0 text-[#505662] text-[16px] w-[220px]">
        <p className="leading-[normal] whitespace-pre-wrap">Please go back and try again</p>
      </div>
    </div>
  );
}

function FormSection() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-center justify-center relative shrink-0" data-name="Form Section">
      <Failed />
      <MessageContainer />
    </div>
  );
}

function FormContainer() {
  return (
    <div className="content-stretch flex flex-col items-start pb-[40px] relative shrink-0" data-name="Form Container">
      <FormSection />
    </div>
  );
}

function ButtonDefault() {
  return (
    <div className="bg-[#97144d] content-stretch flex gap-[8px] h-[48px] items-center justify-center overflow-clip px-[24px] py-[10px] relative rounded-[200px] shrink-0 w-[258px]" data-name="Button/Default">
      <div className="flex flex-col font-['Noto_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-center text-white whitespace-nowrap">
        <p className="leading-[normal]">Try Again</p>
      </div>
    </div>
  );
}

function CtaContainer() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[10px] items-center pb-[24px] pt-[16px] px-[16px] relative shrink-0 w-[360px]" data-name="CTA container">
      <ButtonDefault />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-center pt-[64px] relative shrink-0">
      <FormContainer />
      <CtaContainer />
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[160px] items-center overflow-clip relative rounded-[16px] size-full" data-name="358">
      <NavigationHeaders />
      <Frame />
    </div>
  );
}