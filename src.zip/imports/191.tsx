function NavigationHeaders() {
  return (
    <div className="bg-[#143a72] content-stretch flex gap-[8px] items-center max-w-[440px] min-h-[64px] min-w-[320px] px-[16px] py-[12px] relative shrink-0 w-[360px]" data-name="Navigation/Headers">
      <div aria-hidden="true" className="absolute border-[rgba(232,235,241,0.2)] border-b border-solid inset-0 pointer-events-none shadow-[0px_4px_12px_0px_rgba(144,164,202,0.2)]" />
      <div className="flex flex-[1_0_0] flex-col font-['Noto_Sans:Regular',sans-serif] justify-center leading-[0] min-h-px min-w-px not-italic relative text-[13px] text-white">
        <p className="leading-[normal] whitespace-pre-wrap">Verification</p>
      </div>
    </div>
  );
}

function LoaderRipple() {
  return (
    <div className="h-[36px] relative shrink-0 w-[84px]" data-name="Loader/Ripple">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 84 36">
        <g id="Loader/Ripple">
          <g id="frame" />
          <circle cx="6" cy="18" fill="var(--fill-0, #424752)" id="atom" r="6" />
          <circle cx="24" cy="18" fill="var(--fill-0, #424752)" id="atom_2" r="6" />
          <circle cx="42" cy="18" fill="var(--fill-0, #424752)" id="atom_3" r="6" />
          <circle cx="60" cy="18" fill="var(--fill-0, #424752)" id="atom_4" r="6" />
          <circle cx="78" cy="18" fill="var(--fill-0, #424752)" id="atom_5" r="6" />
        </g>
      </svg>
    </div>
  );
}

function MessageContainer() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center justify-center leading-[0] not-italic relative shrink-0 text-center w-full" data-name="Message Container">
      <div className="flex flex-col font-['Lato:Regular',sans-serif] justify-center relative shrink-0 text-[#171a21] text-[20px] tracking-[-0.04px] whitespace-nowrap">
        <p className="leading-[normal]">Verifying your OTP</p>
      </div>
      <div className="flex flex-col font-['Noto_Sans:Regular',sans-serif] justify-center min-w-full relative shrink-0 text-[#505662] text-[16px] w-[min-content]">
        <p className="leading-[normal] whitespace-pre-wrap">
          Please do not close or go back
          <br aria-hidden="true" />
          from this screen
        </p>
      </div>
    </div>
  );
}

function FormSection() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-center justify-center relative shrink-0 w-full" data-name="Form Section">
      <LoaderRipple />
      <MessageContainer />
    </div>
  );
}

function FormContainer() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start pb-[40px] pt-[120px] relative shrink-0 w-[328px]" data-name="Form Container">
      <FormSection />
    </div>
  );
}

export default function Component() {
  return (
    <div className="bg-white content-stretch flex flex-col gap-[160px] items-center overflow-clip relative rounded-[16px] size-full" data-name="191">
      <NavigationHeaders />
      <FormContainer />
    </div>
  );
}