import { useState } from 'react';
import { Button, SimpleInput, RadioButtonGroup, Tabs, Divider, DatePicker, MobileInput, OTPInput } from '@axismaxlife/unified-ui-components-library';
import svgPathsDesktop from '../imports/svg-zhe7urh67g';
import svgPathsMobile from '../imports/svg-ym7r4k8uqq';
import svgPathsNote from '../imports/svg-5nhlcqnodh';
import svgPathsConsequences from '../imports/svg-thfcyxija1';
import svgPathsFooter from '../imports/svg-we8msgejjm';
import imgCheckShield from 'figma:asset/5631eb4f964a2747f26b3b187dd21183ca197966.png';
import imgFamilyDesktop from 'figma:asset/f746ffbd77226d4865f6520aca998d78bff8113e.png';
import { headingStyles, bodyStyles } from './constants/typography';
import {
  flexContainerStyles,
  gapStyles,
  cardStyles,
  marginStyles,
  iconContainerStyles,
  headerStyles,
  backgroundStyles,
  fixedBottomStyles,
  stepperStyles,
  dividerStyles,
} from './constants/layoutStyles';
import { OTPScreen } from './components/OTPScreen';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'form' | 'otp'>('form');
  const [selectedOption, setSelectedOption] = useState<string>('');
  const [selectedTab, setSelectedTab] = useState<string>('mobile');
  const [mobileNumber, setMobileNumber] = useState('');
  const [emailAddress, setEmailAddress] = useState('');
  const [policyNumber, setPolicyNumber] = useState('');
  const [dob, setDob] = useState<Date | null>(null);
  const [dobCalendarOpen, setDobCalendarOpen] = useState(false);
  const [yourMobile, setYourMobile] = useState('');
  const [yourDob, setYourDob] = useState<Date | null>(null);
  const [yourDobCalendarOpen, setYourDobCalendarOpen] = useState(false);
  const [otp, setOtp] = useState('');

  // Radio button options for Glide RadioButtonGroup
  const radioOptions = [
    { label: 'Yes', value: 'yes' },
    { label: 'No', value: 'no' }
  ];

  // Tab items for Glide Tabs
  const tabItems = [
    { id: 'mobile', label: 'Mobile No.', content: <div /> },
    { id: 'email', label: 'Email ID', content: <div /> },
    { id: 'policy', label: 'Policy No.', content: <div /> }
  ];

  // Validation logic for "Yes" flow
  const isYesFlowValid = () => {
    if (selectedOption !== 'yes') return false;
    
    // Check DOB is filled
    if (!dob) return false;
    
    // Check selected tab field is valid
    if (selectedTab === 'mobile') {
      return mobileNumber.length === 10;
    } else if (selectedTab === 'email') {
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailAddress);
    } else if (selectedTab === 'policy') {
      return policyNumber.length === 9;
    }
    
    return false;
  };

  // Validation logic for "No" flow
  const isNoFlowValid = () => {
    if (selectedOption !== 'no') return false;
    
    // Check all required fields: policy number, DOB, your mobile, your DOB
    return (
      policyNumber.length === 9 &&
      dob !== null &&
      yourMobile.length === 10 &&
      yourDob !== null
    );
  };

  // Check if continue button should be enabled
  const isContinueEnabled = isYesFlowValid() || isNoFlowValid();

  // Handle Continue button click
  const handleContinue = () => {
    if (isContinueEnabled) {
      setCurrentScreen('otp');
    }
  };

  // Handle back from OTP screen
  const handleBackFromOTP = () => {
    setCurrentScreen('form');
  };

  // If on OTP screen, show OTP component
  if (currentScreen === 'otp') {
    return (
      <OTPScreen
        selectedOption={selectedOption}
        mobileNumber={mobileNumber}
        yourMobile={yourMobile}
        onBack={handleBackFromOTP}
      />
    );
  }

  return (
    <div className="min-h-screen" style={{ background: 'var(--color-surface-bg-white)' }}>
      {/* Mobile Layout */}
      <div className="lg:hidden">
        {/* Header */}
        <div className="flex items-center px-4 py-3 border-b" style={headerStyles.mobileNav}>
          <div className="size-6">
            <svg className="block size-full" fill="none" viewBox="0 0 24 24">
              <path d={svgPathsMobile.p1d9a6a00} style={{ fill: 'var(--color-icon-white)' }} />
            </svg>
          </div>
          <p className="flex-1" style={bodyStyles.smallWhite}>
            Register Death Claim
          </p>
        </div>

        {/* Main Content */}
        <div className="px-4 pt-6 pb-32" style={backgroundStyles.gradientLightInformation}>
          {/* Question */}
          <h2 className="leading-[1.2]" style={{ ...headingStyles.small, marginBottom: 'var(--spacing-medium-24)' }}>
            Do you have the contact details of the Policy holder?
          </h2>

          {/* Radio Button Group - Using Glide Component */}
          <div style={{ marginBottom: 'var(--spacing-medium-24)' }}>
            <RadioButtonGroup
              options={radioOptions}
              selectedValue={selectedOption}
              onChange={(value) => setSelectedOption(value)}
              stacking="vertical"
              device="web"
              showRadioButton
            />

            {/* Yes Flow Content */}
            {selectedOption === 'yes' && (
              <div style={flexContainerStyles.columnGap16Mt16}>
                {/* Tabs - Using Glide Component */}
                <Tabs
                  tabs={tabItems}
                  defaultActiveId={selectedTab}
                  variant="pill"
                  onTabChange={(id) => setSelectedTab(id)}
                />

                {/* Form */}
                <div style={flexContainerStyles.columnGap16}>
                  <p style={bodyStyles.mediumMedium}>
                    <span>Personal details of </span>
                    <span style={{ color: 'var(--color-text-information)' }}>Policy holder</span>
                  </p>

                  {/* Mobile Number Tab */}
                  {selectedTab === 'mobile' && (
                    <MobileInput
                      name="mobileNumber"
                      mobileNumber={mobileNumber}
                      onChange={(countryCode, mobile) => setMobileNumber(mobile)}
                      placeholder="Mobile Number"
                      width="100%"
                      validation={mobileNumber ? (mobileNumber.length === 10 ? 'success' : 'error') : undefined}
                    />
                  )}

                  {/* Email ID Tab */}
                  {selectedTab === 'email' && (
                    <SimpleInput
                      name="emailAddress"
                      type="email"
                      value={emailAddress}
                      onChange={(e) => setEmailAddress(e.target.value)}
                      placeholder="Email Address"
                      width="100%"
                      validation={emailAddress ? (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailAddress) ? 'success' : 'error') : undefined}
                    />
                  )}

                  {/* Policy No Tab */}
                  {selectedTab === 'policy' && (
                    <SimpleInput
                      name="policyNumber"
                      type="text"
                      value={policyNumber}
                      onChange={(e) => setPolicyNumber(e.target.value)}
                      placeholder="9 digit Policy Number"
                      width="100%"
                      maxLength={9}
                      inputMode="numeric"
                      validation={policyNumber ? (policyNumber.length === 9 ? 'success' : 'error') : undefined}
                    />
                  )}

                  {/* Date of Birth */}
                  <DatePicker
                    type="simple"
                    value={dob}
                    openCalendar={dobCalendarOpen}
                    onClose={() => setDobCalendarOpen(false)}
                    onSet={(value) => {
                      setDob(value as Date | null);
                      setDobCalendarOpen(false);
                    }}
                    onClear={() => setDob(null)}
                    inputPlaceholder="Date of Birth of Policy holder (DD/MM/YY)"
                    width="100%"
                    closeIcon={true}
                    showFooterBtns={true}
                    validation={dob ? 'success' : undefined}
                    autoComplete="off"
                  />

                  {/* Continue Button - Using Glide Button */}
                  <Button
                    buttonType="primary"
                    size="default"
                    width="100%"
                    disabled={!isContinueEnabled}
                    onClick={handleContinue}
                  >
                    Continue
                  </Button>
                </div>

                <div style={{ marginTop: 'var(--spacing-medium-24)', marginBottom: 'var(--spacing-medium-24)' }}>
                  <Divider width="40px" />
                </div>
              </div>
            )}

            {/* No Flow - Info Message */}
            {selectedOption === 'no' && (
              <>
                <div className="flex items-start px-4 py-3" style={gapStyles.small8}>
                  <div className="size-6 shrink-0">
                    <svg className="size-full" fill="none" viewBox="0 0 24 24">
                      <path clipRule="evenodd" d={svgPathsMobile.p26811180} fillRule="evenodd" style={{ fill: 'var(--color-icon-default)' }} />
                    </svg>
                  </div>
                  <p className="leading-normal" style={bodyStyles.smallSecondary}>
                    Claims from unregistered numbers may take longer to process
                  </p>
                </div>

                {/* No Flow Content */}
                <div style={flexContainerStyles.columnGap16Mt16}>
                  {/* Policy Holder Details */}
                  <div style={flexContainerStyles.columnGap16}>
                    <p style={bodyStyles.mediumMedium}>
                      <span>Personal details of </span>
                      <span style={{ color: 'var(--color-text-information)' }}>Policy holder</span>
                    </p>

                    <SimpleInput
                      name="policyNumberNo"
                      type="text"
                      value={policyNumber}
                      onChange={(e) => setPolicyNumber(e.target.value)}
                      placeholder="9 digit Policy Number"
                      width="100%"
                      maxLength={9}
                      inputMode="numeric"
                      validation={policyNumber ? (policyNumber.length === 9 ? 'success' : 'error') : undefined}
                    />

                    <DatePicker
                      type="simple"
                      value={dob}
                      openCalendar={dobCalendarOpen}
                      onClose={() => setDobCalendarOpen(false)}
                      onSet={(value) => {
                        setDob(value as Date | null);
                        setDobCalendarOpen(false);
                      }}
                      onClear={() => setDob(null)}
                      inputPlaceholder="Date of Birth of Policy holder (DD/MM/YY)"
                      width="100%"
                      closeIcon
                      showFooterBtns
                      validation={dob ? 'success' : undefined}
                      autoComplete="off"
                    />
                  </div>

                  {/* Your Personal Details */}
                  <div style={flexContainerStyles.columnGap16}>
                    <p style={bodyStyles.mediumMedium}>
                      <span style={{ color: 'var(--color-text-information)' }}>Your</span>
                      <span> personal details</span>
                    </p>

                    <MobileInput
                      name="yourMobileNo"
                      mobileNumber={yourMobile}
                      onChange={(countryCode, mobile) => setYourMobile(mobile)}
                      placeholder="Mobile Number"
                      width="100%"
                      validation={yourMobile ? (yourMobile.length === 10 ? 'success' : 'error') : undefined}
                    />

                    <DatePicker
                      type="simple"
                      value={yourDob}
                      openCalendar={yourDobCalendarOpen}
                      onClose={() => setYourDobCalendarOpen(false)}
                      onSet={(value) => {
                        setYourDob(value as Date | null);
                        setYourDobCalendarOpen(false);
                      }}
                      onClear={() => setYourDob(null)}
                      inputPlaceholder="Your Date of Birth (DD/MM/YY)"
                      width="100%"
                      closeIcon={true}
                      showFooterBtns={true}
                      validation={yourDob ? 'success' : undefined}
                      autoComplete="off"
                    />
                  </div>

                  {/* Continue Button - Using Glide Button */}
                  <Button
                    buttonType="primary"
                    size="default"
                    width="100%"
                    disabled={!isContinueEnabled}
                    onClick={handleContinue}
                  >
                    Continue
                  </Button>

                  <div style={{ marginTop: 'var(--spacing-medium-24)', marginBottom: 'var(--spacing-medium-24)' }}>
                    <Divider width="40px" />
                  </div>
                </div>
              </>
            )}
          </div>

          {/* 3 Easy Steps Section */}
          <div style={{ marginBottom: 'var(--spacing-medium-24)' }}>
            <h3 className="text-center" style={{ ...bodyStyles.mediumBoldBlue, marginBottom: 'var(--spacing-medium-20)' }}>
              3 Easy Steps to Claim Submission
            </h3>

            {/* Progress Stepper */}
            <div className="flex items-start" style={{ marginBottom: 'var(--spacing-medium-24)' }}>
              {/* Step 1 */}
              <div className="flex-1 flex flex-col py-2" style={{ gap: 'var(--spacing-small-4)' }}>
                <div className="flex items-center">
                  <div className="flex-1" />
                  <div className="relative flex items-center justify-center size-5">
                    <svg className="size-full" fill="none" viewBox="0 0 20 20">
                      <circle cx="10" cy="10" r="9.25" strokeWidth="1.5" style={{ fill: 'var(--color-surface-bg-bold-midnight)', stroke: 'var(--color-border-information)' }} />
                    </svg>
                    <span className="absolute" style={bodyStyles.microBoldWhite}>1</span>
                  </div>
                  <div className="flex-1 h-0.5" style={{ background: 'var(--color-surface-bg-midnight)' }} />
                </div>
                <div className="text-center">
                  <p className="leading-normal" style={bodyStyles.smallSemibold}>
                    Verify<br />yourself
                  </p>
                  <p className="leading-normal" style={bodyStyles.micro}>
                    Policy check and eKYC
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="flex-1 flex flex-col py-2" style={{ gap: 'var(--spacing-small-4)' }}>
                <div className="flex items-center">
                  <div className="flex-1 h-0.5" style={{ background: 'var(--color-surface-bg-midnight)' }} />
                  <div className="relative flex items-center justify-center size-5">
                    <svg className="size-full" fill="none" viewBox="0 0 20 20">
                      <circle cx="10" cy="10" r="9.25" strokeWidth="1.5" style={{ fill: 'var(--color-surface-bg-bold-midnight)', stroke: 'var(--color-border-information)' }} />
                    </svg>
                    <span className="absolute" style={bodyStyles.microBoldWhite}>2</span>
                  </div>
                  <div className="flex-1 h-0.5" style={{ background: 'var(--color-surface-bg-midnight)' }} />
                </div>
                <div className="text-center">
                  <p className="leading-normal" style={bodyStyles.small}>
                    Incident<br />details
                  </p>
                  <p className="leading-normal" style={bodyStyles.micro}>
                    Event details and document upload
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="flex-1 flex flex-col py-2" style={{ gap: 'var(--spacing-small-4)' }}>
                <div className="flex items-center">
                  <div className="flex-1 h-0.5" style={{ background: 'var(--color-surface-bg-midnight)' }} />
                  <div className="relative flex items-center justify-center size-5">
                    <svg className="size-full" fill="none" viewBox="0 0 20 20">
                      <circle cx="10" cy="10" r="9.25" strokeWidth="1.5" style={{ fill: 'var(--color-surface-bg-bold-midnight)', stroke: 'var(--color-border-information)' }} />
                    </svg>
                    <span className="absolute" style={bodyStyles.microBoldWhite}>3</span>
                  </div>
                  <div className="flex-1" />
                </div>
                <div className="text-center">
                  <p className="leading-normal" style={bodyStyles.small}>
                    Add<br />bank
                  </p>
                  <p className="leading-normal" style={bodyStyles.micro}>
                    Bank account confirmation
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Before You Begin */}
          <div className="relative" style={{ background: 'var(--color-surface-bg-white)', boxShadow: 'var(--shadow-focused)', borderRadius: 'var(--corner-radius-12)', padding: 'var(--padding-medium-20) var(--padding-medium-24)' }}>
            {/* Header */}
            <div style={{ marginBottom: 'var(--spacing-large-40)' }}>
              <p style={{ ...headingStyles.small, marginBottom: 'var(--spacing-small-8)' }}>
                Before you begin
              </p>
              <p style={bodyStyles.mediumSecondary}>
                You only need a few details to get started:
              </p>
            </div>

            {/* Documents List */}
            <div className="flex flex-col" style={{ gap: 'var(--spacing-medium-24)' }}>
              {/* Death Certificate */}
              <div className="flex items-center" style={{ gap: 'var(--spacing-medium-16)' }}>
                <div className="flex items-center justify-center shrink-0" style={{ background: 'var(--color-surface-bg-information)', padding: 'var(--padding-medium-16)', borderRadius: 'var(--corner-radius-round)' }}>
                  <div className="size-4">
                    <svg className="size-full" fill="none" viewBox="0 0 16 16">
                      <path d={svgPathsDesktop.p2955e500} style={{ fill: 'var(--color-icon-brand-blue)' }} />
                    </svg>
                  </div>
                </div>
                <p className="leading-normal" style={bodyStyles.smallSecondary}>
                  Death Certificate
                </p>
              </div>

              {/* Policy Pack and Other Documents */}
              <div className="flex items-center" style={{ gap: 'var(--spacing-medium-16)' }}>
                <div className="flex items-center justify-center shrink-0" style={{ background: 'var(--color-surface-bg-information)', padding: 'var(--padding-medium-16)', borderRadius: 'var(--corner-radius-round)' }}>
                  <div className="size-4">
                    <svg className="size-full" fill="none" viewBox="0 0 16 16">
                      <path d={svgPathsDesktop.pf3c9900} style={{ fill: 'var(--color-icon-brand-blue)' }} />
                    </svg>
                  </div>
                </div>
                <p className="leading-normal" style={bodyStyles.smallSecondary}>
                  Policy Pack and<br />Other Documents
                </p>
              </div>

              {/* EKYC Documents */}
              <div className="flex items-center" style={{ gap: 'var(--spacing-medium-16)' }}>
                <div className="flex items-center justify-center shrink-0" style={{ background: 'var(--color-surface-bg-information)', padding: 'var(--padding-medium-16)', borderRadius: 'var(--corner-radius-round)' }}>
                  <div className="size-4">
                    <svg className="size-full" fill="none" viewBox="0 0 16 16">
                      <path d={svgPathsDesktop.pf3c9900} style={{ fill: 'var(--color-icon-brand-blue)' }} />
                    </svg>
                  </div>
                </div>
                <p className="leading-normal" style={bodyStyles.smallSecondary}>
                  EKYC Documents<br />(Yours and Insurer's)
                </p>
              </div>
            </div>

            {/* Check Shield Watermark */}
            <div className="absolute w-11 h-11" style={{ left: '391px', top: '99px', opacity: '0.24' }}>
              <img alt="" className="size-full object-cover" src={imgCheckShield} />
            </div>

            {/* Family Image */}
            <div className="absolute overflow-hidden" style={{ width: '341px', height: '228px', left: '238px', top: '156px', borderRadius: 'var(--corner-radius-16)' }}>
              <div className="relative" style={{ width: '450px', height: '281px', left: '-53px', top: '-46px' }}>
                <img alt="Family" className="size-full object-cover" src={imgFamilyDesktop} />
              </div>
            </div>
          </div>

          {/* Please Note Section */}
          <div className="flex flex-col" style={{ background: 'var(--color-surface-bg-white)', borderRadius: 'var(--corner-radius-8)', marginBottom: 'var(--spacing-medium-24)', padding: 'var(--padding-medium-24)', gap: 'var(--spacing-medium-16)' }}>
            <p style={bodyStyles.smallSemiboldDefault}>
              Please note:
            </p>

            <div className="flex flex-col" style={{ gap: 'var(--spacing-medium-16)' }}>
              {/* Point 1 - Video Camera Icon */}
              <div className="flex items-start" style={{ gap: 'var(--spacing-medium-12)' }}>
                <div className="size-4 shrink-0">
                  <svg className="size-full" fill="none" viewBox="0 0 16 16">
                    <path d={svgPathsNote.p99b6100} style={{ fill: 'var(--color-icon-default)' }} />
                  </svg>
                </div>
                <p className="leading-normal" style={bodyStyles.smallSecondary}>
                  The information you share in the claim form will be officially recorded for the policy.
                </p>
              </div>

              {/* Point 2 - Recenter Icon */}
              <div className="flex items-start" style={{ gap: 'var(--spacing-medium-12)' }}>
                <div className="size-4 shrink-0">
                  <svg className="size-full" fill="none" viewBox="0 0 16 16">
                    <g clipPath="url(#clip0_recenter)">
                      <path d={svgPathsNote.p2d52e3c0} style={{ fill: 'var(--color-icon-default)' }} />
                    </g>
                    <defs>
                      <clipPath id="clip0_recenter">
                        <rect fill="white" height="16" width="16" />
                      </clipPath>
                    </defs>
                  </svg>
                </div>
                <p className="leading-normal" style={bodyStyles.smallSecondary}>
                  Please ensure the information you are sharing is correct.
                </p>
              </div>

              {/* Point 3 - Password Icon */}
              <div className="flex items-start" style={{ gap: 'var(--spacing-medium-12)' }}>
                <div className="size-4 shrink-0">
                  <svg className="size-full" fill="none" viewBox="0 0 16 16">
                    <path d={svgPathsNote.p2ebf0a00} style={{ fill: 'var(--color-icon-default)' }} />
                  </svg>
                </div>
                <p className="leading-normal" style={bodyStyles.smallSecondary}>
                  Our team will never ask you to share the OTP.
                </p>
              </div>
            </div>
          </div>

          {/* Incorrect Information Consequences Section */}
          <div className="flex flex-col" style={{ background: 'var(--color-surface-bg-white)', borderRadius: 'var(--corner-radius-8)', marginBottom: 'var(--spacing-medium-24)', padding: 'var(--padding-medium-24)', gap: 'var(--spacing-medium-16)' }}>
            <p className="leading-normal" style={bodyStyles.smallMediumSecondary}>
              Providing incorrect or misleading information, whether intentionally or unintentionally can lead to:
            </p>

            <div className="flex flex-col" style={{ gap: 'var(--spacing-medium-16)' }}>
              {/* Point 1 - Policy Icon */}
              <div className="flex items-center" style={{ gap: 'var(--spacing-small-8)' }}>
                <div className="size-6 shrink-0">
                  <svg className="size-full" fill="none" viewBox="0 0 24 24">
                    <path d={svgPathsConsequences.p12a00d80} style={{ fill: 'var(--color-icon-default)' }} />
                  </svg>
                </div>
                <p className="leading-normal" style={bodyStyles.smallSecondary}>
                  Delay in Policy Issuance
                </p>
              </div>

              {/* Point 2 - Dangerous/Cancel Icon */}
              <div className="flex items-center" style={{ gap: 'var(--spacing-small-8)' }}>
                <div className="size-6 shrink-0">
                  <svg className="size-full" fill="none" viewBox="0 0 24 24">
                    <path d={svgPathsConsequences.p5517f00} style={{ fill: 'var(--color-icon-default)' }} />
                  </svg>
                </div>
                <p className="leading-normal" style={bodyStyles.smallSecondary}>
                  Policy Cancellation
                </p>
              </div>

              {/* Point 3 - Contract Delete Icon */}
              <div className="flex items-center" style={{ gap: 'var(--spacing-small-8)' }}>
                <div className="size-6 shrink-0">
                  <svg className="size-full" fill="none" viewBox="0 0 21.1765 21.1765">
                    <path d={svgPathsConsequences.p3a3b6400} style={{ fill: 'var(--color-icon-default)' }} />
                  </svg>
                </div>
                <p className="leading-normal" style={bodyStyles.smallSecondary}>
                  Claim Rejection
                </p>
              </div>

              {/* Point 4 - Contract Delete Icon (No third party) */}
              <div className="flex items-center" style={{ gap: 'var(--spacing-small-8)' }}>
                <div className="size-6 shrink-0">
                  <svg className="size-full" fill="none" viewBox="0 0 21.1765 21.1765">
                    <path d={svgPathsConsequences.p3a3b6400} style={{ fill: 'var(--color-icon-default)' }} />
                  </svg>
                </div>
                <p className="leading-normal" style={bodyStyles.smallSecondary}>
                  No third party involvement allowed
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Fixed Bottom CTA - Using Glide Button */}
        <div className="fixed bottom-0 left-0 right-0 border-t px-4 pt-4 pb-6" style={{ background: 'var(--color-surface-bg-white)', borderTopColor: 'var(--color-border-mb100)' }}>
          <Button
            buttonType="primary"
            size="default"
            width="100%"
            disabled={!isContinueEnabled}
            onClick={handleContinue}
          >
            Continue
          </Button>
        </div>
      </div>

      {/* Desktop Layout */}
      <div className="hidden lg:block">
        {/* Desktop Main Content */}
        <div className="flex min-h-screen">
          {/* Left Side - Steps and Info */}
        <div className="w-1/2 p-12 flex items-center justify-center" style={{ background: 'var(--gradient-alert-lightInformation)' }}>
          <div className="max-w-lg">
            {/* 3 Easy Steps */}
            <div style={{ marginBottom: 'var(--spacing-large-40)' }}>
              <h1 className="text-center" style={{ ...headingStyles.mediumBold, color: 'var(--color-text-blue)', marginBottom: 'var(--spacing-large-32)' }}>
                3 Easy Steps to Claim Submission
              </h1>

              {/* Desktop Progress Stepper */}
              <div className="flex items-start" style={{ marginBottom: 'var(--spacing-large-32)' }}>
                {[1, 2, 3].map((step, i) => (
                  <div key={step} className="flex-1 flex flex-col py-2" style={{ gap: 'var(--spacing-small-8)' }}>
                    <div className="flex items-center">
                      {i > 0 && <div className="flex-1 h-0.5" style={{ background: 'var(--color-surface-bg-midnight)' }} />}
                      {i === 0 && <div className="flex-1" />}
                      <div className="relative flex items-center justify-center w-7 h-7">
                        <svg className="size-full" fill="none" viewBox="0 0 26 26">
                          <circle cx="13" cy="13" r="12.025" strokeWidth="1.95" style={{ fill: 'var(--color-surface-bg-bold-midnight)', stroke: 'var(--color-border-information)' }} />
                        </svg>
                        <span className="absolute" style={bodyStyles.mediumBold}>{step}</span>
                      </div>
                      {i < 2 && <div className="flex-1 h-0.5" style={{ background: 'var(--color-surface-bg-midnight)' }} />}
                      {i === 2 && <div className="flex-1" />}
                    </div>
                    <div className="text-center px-2">
                      <p className="leading-tight" style={{ ...bodyStyles.mediumSemibold, marginBottom: 'var(--spacing-small-4)' }}>
                        {step === 1 && 'Verify Yourself'}
                        {step === 2 && 'Incident Details'}
                        {step === 3 && 'Add Bank'}
                      </p>
                      <p className="leading-tight" style={bodyStyles.smallSecondary}>
                        {step === 1 && <>Policy check<br />and eKYC</>}
                        {step === 2 && <>Event details and<br />document upload</>}
                        {step === 3 && <>Bank account<br />confirmation</>}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Before You Begin */}
            <div className="relative" style={{ background: 'var(--color-surface-bg-white)', boxShadow: 'var(--shadow-focused)', borderRadius: 'var(--corner-radius-12)', padding: 'var(--padding-medium-20) var(--padding-medium-24)' }}>
              {/* Header */}
              <div style={{ marginBottom: 'var(--spacing-large-40)' }}>
                <p style={{ ...headingStyles.small, marginBottom: 'var(--spacing-small-8)' }}>
                  Before you begin
                </p>
                <p style={bodyStyles.mediumSecondary}>
                  You only need a few details to get started:
                </p>
              </div>

              {/* Documents List */}
              <div className="flex flex-col" style={{ gap: 'var(--spacing-medium-24)' }}>
                {/* Death Certificate */}
                <div className="flex items-center" style={{ gap: 'var(--spacing-medium-16)' }}>
                  <div className="flex items-center justify-center shrink-0" style={{ background: 'var(--color-surface-bg-information)', padding: 'var(--padding-medium-16)', borderRadius: 'var(--corner-radius-round)' }}>
                    <div className="size-4">
                      <svg className="size-full" fill="none" viewBox="0 0 16 16">
                        <path d={svgPathsDesktop.p2955e500} style={{ fill: 'var(--color-icon-brand-blue)' }} />
                      </svg>
                    </div>
                  </div>
                  <p className="leading-normal" style={bodyStyles.smallSecondary}>
                    Death Certificate
                  </p>
                </div>

                {/* Policy Pack and Other Documents */}
                <div className="flex items-center" style={{ gap: 'var(--spacing-medium-16)' }}>
                  <div className="flex items-center justify-center shrink-0" style={{ background: 'var(--color-surface-bg-information)', padding: 'var(--padding-medium-16)', borderRadius: 'var(--corner-radius-round)' }}>
                    <div className="size-4">
                      <svg className="size-full" fill="none" viewBox="0 0 16 16">
                        <path d={svgPathsDesktop.pf3c9900} style={{ fill: 'var(--color-icon-brand-blue)' }} />
                      </svg>
                    </div>
                  </div>
                  <p className="leading-normal" style={bodyStyles.smallSecondary}>
                    Policy Pack and<br />Other Documents
                  </p>
                </div>

                {/* EKYC Documents */}
                <div className="flex items-center" style={{ gap: 'var(--spacing-medium-16)' }}>
                  <div className="flex items-center justify-center shrink-0" style={{ background: 'var(--color-surface-bg-information)', padding: 'var(--padding-medium-16)', borderRadius: 'var(--corner-radius-round)' }}>
                    <div className="size-4">
                      <svg className="size-full" fill="none" viewBox="0 0 16 16">
                        <path d={svgPathsDesktop.pf3c9900} style={{ fill: 'var(--color-icon-brand-blue)' }} />
                      </svg>
                    </div>
                  </div>
                  <p className="leading-normal" style={bodyStyles.smallSecondary}>
                    EKYC Documents<br />(Yours and Insurer's)
                  </p>
                </div>
              </div>

              {/* Check Shield Watermark */}
              <div className="absolute w-11 h-11" style={{ left: '391px', top: '99px', opacity: '0.24' }}>
                <img alt="" className="size-full object-cover" src={imgCheckShield} />
              </div>

              {/* Family Image */}
              <div className="absolute overflow-hidden" style={{ width: '341px', height: '228px', left: '238px', top: '156px', borderRadius: 'var(--corner-radius-16)' }}>
                <div className="relative" style={{ width: '450px', height: '281px', left: '-53px', top: '-46px' }}>
                  <img alt="Family" className="size-full object-cover" src={imgFamilyDesktop} />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side - Form */}
        <div className="w-1/2 flex items-center justify-center p-12 relative">
          {/* Back Arrow */}
          <button className="absolute left-0 top-0 size-6 shrink-0">
            <svg className="size-full" fill="none" viewBox="0 0 24 24">
              <path d={svgPathsDesktop.p33fdf300} style={{ fill: 'var(--color-icon-default)' }} />
            </svg>
          </button>

          <div className="w-full max-w-md">
            <h2 className="leading-[1.2]" style={headingStyles.mediumBoldWithMargin}>
              Do you have the contact<br />details of the Policy holder?
            </h2>

            {/* Radio Button Group - Using Glide Component */}
            <div style={marginStyles.bottom24}>
              <RadioButtonGroup
                options={radioOptions}
                selectedValue={selectedOption}
                onChange={(value) => setSelectedOption(value)}
                stacking="vertical"
                device="web"
                showRadioButton
              />

              {/* Yes Flow Content */}
              {selectedOption === 'yes' && (
                <div style={flexContainerStyles.columnGap16Mt16}>
                  {/* Tabs - Using Glide Component */}
                  <Tabs
                    tabs={tabItems}
                    defaultActiveId={selectedTab}
                    variant="pill"
                    onTabChange={(id) => setSelectedTab(id)}
                  />

                  {/* Form */}
                  <div style={flexContainerStyles.columnGap16}>
                    <p style={bodyStyles.mediumMedium}>
                      <span>Personal details of </span>
                      <span style={{ color: 'var(--color-text-information)' }}>Policy holder</span>
                    </p>

                    {/* Mobile Number Tab */}
                    {selectedTab === 'mobile' && (
                      <MobileInput
                        name="mobileNumberDesktop"
                        mobileNumber={mobileNumber}
                        onChange={(countryCode, mobile) => setMobileNumber(mobile)}
                        placeholder="Mobile Number"
                        width="100%"
                        validation={mobileNumber ? (mobileNumber.length === 10 ? 'success' : 'error') : undefined}
                      />
                    )}

                    {/* Email ID Tab */}
                    {selectedTab === 'email' && (
                      <SimpleInput
                        name="emailAddressDesktop"
                        type="email"
                        value={emailAddress}
                        onChange={(e) => setEmailAddress(e.target.value)}
                        placeholder="Email Address"
                        width="100%"
                        validation={emailAddress ? (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailAddress) ? 'success' : 'error') : undefined}
                      />
                    )}

                    {/* Policy No Tab */}
                    {selectedTab === 'policy' && (
                      <SimpleInput
                        name="policyNumberDesktop"
                        type="text"
                        value={policyNumber}
                        onChange={(e) => setPolicyNumber(e.target.value)}
                        placeholder="9 digit Policy Number"
                        width="100%"
                        maxLength={9}
                        inputMode="numeric"
                        validation={policyNumber ? (policyNumber.length === 9 ? 'success' : 'error') : undefined}
                      />
                    )}

                    {/* Date of Birth */}
                    <DatePicker
                      type="simple"
                      value={dob}
                      openCalendar={dobCalendarOpen}
                      onClose={() => setDobCalendarOpen(false)}
                      onSet={(value) => {
                        setDob(value as Date | null);
                        setDobCalendarOpen(false);
                      }}
                      onClear={() => setDob(null)}
                      inputPlaceholder="Date of Birth of Policy holder (DD/MM/YY)"
                      width="100%"
                      closeIcon
                      showFooterBtns
                      validation={dob ? 'success' : undefined}
                      autoComplete="off"
                    />

                    {/* Continue Button - Using Glide Button */}
                    <Button
                      buttonType="primary"
                      size="default"
                      width="100%"
                      disabled={!isContinueEnabled}
                      onClick={handleContinue}
                    >
                      Continue
                    </Button>
                  </div>
                </div>
              )}

              {/* No Flow - Info Message */}
              {selectedOption === 'no' && (
                <>
                  <div className="flex items-start px-4 py-3" style={gapStyles.small8}>
                    <div className="size-6 shrink-0">
                      <svg className="size-full" fill="none" viewBox="0 0 24 24">
                        <path clipRule="evenodd" d={svgPathsDesktop.p26811180} fillRule="evenodd" style={{ fill: 'var(--color-icon-default)' }} />
                      </svg>
                    </div>
                    <p className="leading-normal" style={bodyStyles.smallSecondary}>
                      Claims from unregistered numbers may take longer to process
                    </p>
                  </div>

                  {/* No Flow Content */}
                  <div style={flexContainerStyles.columnGap16Mt16}>
                    {/* Policy Holder Details */}
                    <div style={flexContainerStyles.columnGap16}>
                      <p style={bodyStyles.mediumMedium}>
                        <span>Personal details of </span>
                        <span style={{ color: 'var(--color-text-information)' }}>Policy holder</span>
                      </p>

                      <SimpleInput
                        name="policyNumberDesktopNo"
                        type="text"
                        value={policyNumber}
                        onChange={(e) => setPolicyNumber(e.target.value)}
                        placeholder="9 digit Policy Number"
                        width="100%"
                        maxLength={9}
                        inputMode="numeric"
                        validation={policyNumber ? (policyNumber.length === 9 ? 'success' : 'error') : undefined}
                      />

                      <DatePicker
                        type="simple"
                        value={dob}
                        openCalendar={dobCalendarOpen}
                        onClose={() => setDobCalendarOpen(false)}
                        onSet={(value) => {
                          setDob(value as Date | null);
                          setDobCalendarOpen(false);
                        }}
                        onClear={() => setDob(null)}
                        inputPlaceholder="Date of Birth of Policy holder (DD/MM/YY)"
                        width="100%"
                        closeIcon
                        showFooterBtns
                        validation={dob ? 'success' : undefined}
                        autoComplete="off"
                      />
                    </div>

                    {/* Your Personal Details */}
                    <div style={flexContainerStyles.columnGap16}>
                      <p style={bodyStyles.mediumMedium}>
                        <span style={{ color: 'var(--color-text-information)' }}>Your</span>
                        <span> personal details</span>
                      </p>

                      <MobileInput
                        name="yourMobileDesktopNo"
                        mobileNumber={yourMobile}
                        onChange={(countryCode, mobile) => setYourMobile(mobile)}
                        placeholder="Mobile Number"
                        width="100%"
                        validation={yourMobile ? (yourMobile.length === 10 ? 'success' : 'error') : undefined}
                      />

                      <DatePicker
                        type="simple"
                        value={yourDob}
                        openCalendar={yourDobCalendarOpen}
                        onClose={() => setYourDobCalendarOpen(false)}
                        onSet={(value) => {
                          setYourDob(value as Date | null);
                          setYourDobCalendarOpen(false);
                        }}
                        onClear={() => setYourDob(null)}
                        inputPlaceholder="Your Date of Birth (DD/MM/YY)"
                        width="100%"
                        closeIcon
                        showFooterBtns
                        validation={yourDob ? 'success' : undefined}
                        autoComplete="off"
                      />
                    </div>

                    {/* Continue Button - Using Glide Button */}
                    <Button
                      buttonType="primary"
                      size="default"
                      width="100%"
                      disabled={!isContinueEnabled}
                      onClick={handleContinue}
                    >
                      Continue
                    </Button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
        </div>

        {/* Desktop Footer */}
        <div className="flex w-full">
          <div className="w-1/2 px-8 py-5" style={{ background: 'var(--gradient-alert-lightInformation)' }}>
            <div className="max-w-lg mx-auto">
              <div className="flex flex-col border px-6 py-4" style={{ background: 'var(--color-surface-bg-white)', borderColor: 'var(--color-border-n100)', borderRadius: 'var(--corner-radius-16)', gap: 'var(--spacing-medium-16)' }}>
                <p style={bodyStyles.mediumMediumSecondary}>Please note:</p>
                <div className="flex flex-col" style={{ gap: 'var(--spacing-medium-16)' }}>
                  <div className="flex items-start" style={{ gap: 'var(--spacing-medium-12)' }}>
                    <div className="size-4 shrink-0"><svg className="size-full" fill="none" viewBox="0 0 16 16"><path d={svgPathsFooter.p99b6100} style={{ fill: 'var(--color-icon-default)' }} /></svg></div>
                    <p className="leading-normal flex-1" style={bodyStyles.smallSecondary}>The information you share in the claim form will be officially recorded for the policy.</p>
                  </div>
                  <div className="flex items-start" style={{ gap: 'var(--spacing-medium-12)' }}>
                    <div className="size-4 shrink-0"><svg className="size-full" fill="none" viewBox="0 0 16 16"><g clipPath="url(#clip0_2001_6186)"><path d={svgPathsFooter.p2d52e3c0} style={{ fill: 'var(--color-icon-default)' }} /></g><defs><clipPath id="clip0_2001_6186"><rect fill="white" height="16" width="16" /></clipPath></defs></svg></div>
                    <p className="leading-normal flex-1" style={bodyStyles.smallSecondary}>Please ensure the information you are sharing is correct.</p>
                  </div>
                  <div className="flex items-start" style={{ gap: 'var(--spacing-medium-12)' }}>
                    <div className="size-4 shrink-0"><svg className="size-full" fill="none" viewBox="0 0 16 16"><path d={svgPathsFooter.p2ebf0a00} style={{ fill: 'var(--color-icon-default)' }} /></svg></div>
                    <p className="leading-normal flex-1" style={bodyStyles.smallSecondary}>Our team will never ask you to share the OTP.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="w-1/2 px-8 py-5" style={{ background: 'var(--color-surface-bg-white)' }}>
            <div className="max-w-md mx-auto">
              <div className="flex flex-col px-6 py-4 border" style={{ background: 'var(--color-surface-bg-white)', borderColor: 'var(--color-border-n100)', borderRadius: 'var(--corner-radius-16)', gap: 'var(--spacing-medium-16)' }}>
                <p className="leading-normal" style={bodyStyles.mediumMediumSecondary}>Providing incorrect or misleading information, whether intentionally or unintentionally can lead to:</p>
                <div className="flex flex-col" style={{ gap: 'var(--spacing-medium-16)' }}>
                  <div className="flex items-center" style={{ gap: 'var(--spacing-small-8)' }}>
                    <div className="size-6 shrink-0"><svg className="size-full" fill="none" viewBox="0 0 24 24"><path d={svgPathsFooter.p12a00d80} style={{ fill: 'var(--color-icon-default)' }} /></svg></div>
                    <p className="leading-normal flex-1" style={bodyStyles.smallSecondary}>Delay in Policy Issuance</p>
                  </div>
                  <div className="flex items-center" style={{ gap: 'var(--spacing-small-8)' }}>
                    <div className="size-6 shrink-0"><svg className="size-full" fill="none" viewBox="0 0 24 24"><path d={svgPathsFooter.p5517f00} style={{ fill: 'var(--color-icon-default)' }} /></svg></div>
                    <p className="leading-normal flex-1" style={bodyStyles.smallSecondary}>Policy Cancellation</p>
                  </div>
                  <div className="flex items-center" style={{ gap: 'var(--spacing-small-8)' }}>
                    <div className="size-6 shrink-0"><svg className="size-full" fill="none" viewBox="0 0 21.1765 21.1765"><path d={svgPathsFooter.p3a3b6400} style={{ fill: 'var(--color-icon-default)' }} /></svg></div>
                    <p className="leading-normal flex-1" style={bodyStyles.smallSecondary}>Claim Rejection</p>
                  </div>
                  <div className="flex items-center" style={{ gap: 'var(--spacing-small-8)' }}>
                    <div className="size-6 shrink-0"><svg className="size-full" fill="none" viewBox="0 0 21.1765 21.1765"><path d={svgPathsFooter.p3a3b6400} style={{ fill: 'var(--color-icon-default)' }} /></svg></div>
                    <p className="leading-normal flex-1" style={bodyStyles.smallSecondary}>No third party involvement allowed</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}