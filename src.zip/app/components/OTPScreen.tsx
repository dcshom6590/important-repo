import { useState } from 'react';
import { Button, OTPInput, LoaderRipple } from '@axismaxlife/unified-ui-components-library';
import { headingStyles, bodyStyles } from '../constants/typography';
import { flexContainerStyles, headerStyles } from '../constants/layoutStyles';
import svgPathsMobile from '../../imports/svg-ym7r4k8uqq';
import svgPathsDesktop from '../../imports/svg-zhe7urh67g';
import svgPathsConsequences from '../../imports/svg-thfcyxija1';
import svgPathsNote from '../../imports/svg-5nhlcqnodh';
import svgPathsError from '../../imports/svg-oxcu6xrn6e';
import imgCheckShield from 'figma:asset/5631eb4f964a2747f26b3b187dd21183ca197966.png';
import imgFamilyDesktop from 'figma:asset/f746ffbd77226d4865f6520aca998d78bff8113e.png';
import imgSuccess from 'figma:asset/3b9a9fcae143de986e2f5dcec41fab21a103cee4.png';

interface OTPScreenProps {
  selectedOption: string;
  mobileNumber: string;
  yourMobile: string;
  onBack: () => void;
}

type VerificationStatus = 'idle' | 'verifying' | 'success' | 'error';

export function OTPScreen({ selectedOption, mobileNumber, yourMobile, onBack }: OTPScreenProps) {
  const [otp, setOtp] = useState('');
  const [status, setStatus] = useState<VerificationStatus>('idle');

  // Determine which mobile number to display based on flow
  const displayMobile = selectedOption === 'yes' ? mobileNumber : yourMobile;
  const maskedMobile = `+91 ${displayMobile.slice(0, 2)}****${displayMobile.slice(-2)}`;

  // OTP is valid when all 6 digits are filled
  const isOTPValid = otp.length === 6;

  const handleVerifyOTP = () => {
    setStatus('verifying');
    // Simulate API call
    setTimeout(() => {
      // Randomly show success or error for demo (replace with real API logic)
      const isSuccess = Math.random() > 0.3; // 70% success rate for demo
      setStatus(isSuccess ? 'success' : 'error');
      
      // Auto-navigate after success (optional)
      if (isSuccess) {
        setTimeout(() => {
          console.log('Navigate to next step');
          // Add navigation logic here
        }, 2000);
      }
    }, 2000);
  };

  const handleTryAgain = () => {
    setOtp('');
    setStatus('idle');
  };

  return (
    <>
      {/* Mobile Layout */}
      <div className="lg:hidden min-h-screen flex flex-col" style={{ background: 'var(--color-surface-bg-white)' }}>
        {/* Header */}
        <div className="flex items-center px-4 py-3 border-b" style={headerStyles.mobileNav}>
          <button onClick={onBack} className="size-6 mr-3">
            <svg className="size-full" fill="none" viewBox="0 0 24 24">
              <path d={svgPathsMobile.p1d9a6a00} style={{ fill: 'var(--color-icon-white)', transform: 'rotate(180deg)' }} />
            </svg>
          </button>
          <p className="flex-1" style={bodyStyles.smallWhite}>
            Verification
          </p>
        </div>

        {/* Content - Conditionally render based on status */}
        {status === 'idle' && (
          <div className="flex-1 px-3 pt-6">
            {/* OTP Input - Using Glide Component */}
            <div style={{ marginBottom: 'var(--spacing-medium-24)', display: 'flex', justifyContent: 'center' }}>
              <div style={{ width: '100%', maxWidth: '360px', transform: 'scale(0.95)', transformOrigin: 'center' }}>
                <OTPInput
                  otpLength={6}
                  variant="inline"
                  device="mobile"
                  inputType="simpleInput"
                  mobileNumber={parseInt(displayMobile)}
                  value={otp}
                  onChange={(value: string) => setOtp(value)}
                  onButtonClick={handleVerifyOTP}
                  buttonLabel="Verify and Continue"
                />
              </div>
            </div>
          </div>
        )}

        {status === 'verifying' && (
          <div className="flex-1 flex items-center justify-center" style={{ paddingTop: 'var(--padding-large-120)', paddingBottom: 'var(--padding-large-40)' }}>
            <div className="flex flex-col items-center justify-center w-full" style={{ gap: 'var(--spacing-medium-24)' }}>
              {/* Loader Ripple */}
              <LoaderRipple type="primary" size="default" />
              
              {/* Message Container */}
              <div className="flex flex-col items-center justify-center text-center w-full" style={{ gap: 'var(--spacing-small-8)' }}>
                <h2 style={headingStyles.small}>
                  Verifying your OTP
                </h2>
                <p style={bodyStyles.mediumSecondary}>
                  Please do not close or go back<br />from this screen
                </p>
              </div>
            </div>
          </div>
        )}

        {status === 'success' && (
          <div className="flex-1 flex items-center justify-center" style={{ paddingTop: 'var(--padding-large-120)', paddingBottom: 'var(--padding-large-40)' }}>
            <div className="flex flex-col items-center justify-center" style={{ gap: 'var(--spacing-medium-24)' }}>
              {/* Success Icon */}
              <div className="shrink-0" style={{ width: 'var(--spacing-xtra-large-80)', height: 'var(--spacing-xtra-large-80)' }}>
                <img alt="Success" className="size-full object-cover" src={imgSuccess} />
              </div>
              
              {/* Message Container */}
              <div className="flex flex-col items-center justify-center text-center px-4" style={{ gap: 'var(--spacing-small-8)' }}>
                <h2 style={headingStyles.mediumBold}>
                  Mobile number<br />authenticated!
                </h2>
                <p style={bodyStyles.mediumSecondary}>
                  All future communications will be shared on this number
                </p>
              </div>
            </div>
          </div>
        )}

        {status === 'error' && (
          <div className="flex-1 flex flex-col">
            <div className="flex-1 flex items-center justify-center" style={{ paddingTop: 'var(--padding-large-120)', paddingBottom: 'var(--padding-large-40)' }}>
              <div className="flex flex-col items-center px-4" style={{ gap: 'var(--spacing-medium-24)' }}>
                {/* Error Icon */}
                <div className="shrink-0" style={{ width: 'var(--padding-large-64)', height: 'var(--padding-large-64)' }}>
                  <svg className="block size-full" fill="none" viewBox="0 0 64 64">
                    <circle cx="32" cy="32" r="32" style={{ fill: 'var(--color-icon-danger)' }} />
                    <path d="M54.471 9.529C60.729 15.884 64.202 24.619 64.154 33.692C64.106 42.765 60.54 51.461 54.209 57.742C47.879 64.024 39.179 67.592 30.103 67.64C21.027 67.688 12.288 64.214 5.933 58.009L54.471 9.529Z" style={{ fill: 'var(--color-button-danger-pressed)' }} />
                    <path d="M35.438 32L45.807 21.643C46.056 21.402 46.254 21.113 46.389 20.794C46.524 20.475 46.593 20.132 46.592 19.785C46.591 19.438 46.521 19.095 46.384 18.776C46.248 18.457 46.048 18.169 45.798 17.929C45.548 17.689 45.253 17.502 44.93 17.38C44.607 17.257 44.263 17.202 43.918 17.217C43.573 17.232 43.235 17.316 42.924 17.465C42.613 17.614 42.336 17.825 42.109 18.086L32 28.172L21.893 18.086C21.422 17.636 20.793 17.387 20.14 17.392C19.487 17.396 18.862 17.654 18.398 18.11C17.935 18.567 17.67 19.188 17.665 19.841C17.66 20.493 17.916 21.118 18.373 21.581L28.732 32L18.373 42.419C18.119 42.663 17.918 42.956 17.782 43.282C17.646 43.608 17.578 43.959 17.581 44.314C17.585 44.668 17.659 45.018 17.801 45.342C17.942 45.666 18.147 45.957 18.404 46.196C18.661 46.436 18.965 46.621 19.296 46.739C19.627 46.857 19.979 46.906 20.331 46.884C20.683 46.862 21.026 46.769 21.341 46.611C21.656 46.453 21.936 46.233 22.164 45.964L32 35.878L41.836 45.964C42.071 46.208 42.354 46.402 42.668 46.534C42.982 46.666 43.32 46.734 43.662 46.733C44.004 46.733 44.342 46.664 44.655 46.53C44.968 46.397 45.251 46.201 45.484 45.955C45.717 45.709 45.896 45.419 46.01 45.102C46.124 44.785 46.171 44.448 46.147 44.112C46.124 43.777 46.031 43.449 45.874 43.151C45.717 42.853 45.499 42.591 45.234 42.381L35.438 32Z" style={{ fill: 'var(--color-icon-white)' }} />
                  </svg>
                </div>
                
                {/* Message Container */}
                <div className="flex flex-col items-center justify-center text-center" style={{ gap: 'var(--spacing-small-8)' }}>
                  <h2 style={headingStyles.mediumBold}>
                    Mobile number<br />unable to authenticate
                  </h2>
                  <p style={bodyStyles.mediumSecondary}>
                    Please go back and try again
                  </p>
                </div>
              </div>
            </div>

            {/* Try Again Button */}
            <div className="flex flex-col items-center px-4" style={{ padding: 'var(--padding-medium-16) var(--padding-medium-16) var(--padding-medium-24)', gap: 'var(--spacing-small-10)' }}>
              <Button
                variant="primary"
                size="default"
                onClick={handleTryAgain}
                className="w-full max-w-xs"
              >
                Try Again
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Desktop Layout */}
      <div className="hidden lg:block">
        {status === 'idle' ? (
          <div className="flex min-h-screen">
            {/* Left Side - Steps and Info */}
            <div className="w-1/2 p-12 flex items-center justify-center" style={{ background: 'var(--gradient-alert-lightInformation)' }}>
              <div className="max-w-lg">
                {/* 3 Easy Steps */}
                <div style={{ marginBottom: 'var(--spacing-large-40)' }}>
                  <h1 className="text-center" style={{ ...headingStyles.mediumBold, color: 'var(--color-text-blue)', marginBottom: 'var(--spacing-large-32)' }}>
                    3 Easy Steps to Claim Submission
                  </h1>

                  {/* Desktop Progress Stepper */}
                  <div className="flex items-start" style={{ marginBottom: 'var(--spacing-large-32)' }}>
                    {[1, 2, 3].map((step, i) => (
                      <div key={step} className="flex-1 flex flex-col py-2" style={{ gap: 'var(--spacing-small-8)' }}>
                        <div className="flex items-center">
                          {i > 0 && <div className="flex-1 h-0.5" style={{ background: 'var(--color-surface-bg-midnight)' }} />}
                          {i === 0 && <div className="flex-1" />}
                          <div className="relative flex items-center justify-center w-7 h-7">
                            <svg className="size-full" fill="none" viewBox="0 0 26 26">
                              <circle cx="13" cy="13" r="12.025" strokeWidth="1.95" style={{ fill: 'var(--color-surface-bg-bold-midnight)', stroke: 'var(--color-border-information)' }} />
                            </svg>
                            <span className="absolute" style={bodyStyles.mediumBold}>{step}</span>
                          </div>
                          {i < 2 && <div className="flex-1 h-0.5" style={{ background: 'var(--color-surface-bg-midnight)' }} />}
                          {i === 2 && <div className="flex-1" />}
                        </div>
                        <div className="text-center px-2">
                          <p className="leading-tight" style={{ ...bodyStyles.mediumSemibold, marginBottom: 'var(--spacing-small-4)' }}>
                            {step === 1 && 'Verify Yourself'}
                            {step === 2 && 'Incident Details'}
                            {step === 3 && 'Add Bank'}
                          </p>
                          <p className="leading-tight" style={bodyStyles.smallSecondary}>
                            {step === 1 && <>Policy check<br />and eKYC</>}
                            {step === 2 && <>Event details and<br />document upload</>}
                            {step === 3 && <>Bank account<br />confirmation</>}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Before You Begin */}
                <div className="relative" style={{ background: 'var(--color-surface-bg-white)', boxShadow: 'var(--shadow-focused)', borderRadius: 'var(--corner-radius-12)', padding: 'var(--padding-medium-20) var(--padding-medium-24)' }}>
                  {/* Header */}
                  <div style={{ marginBottom: 'var(--spacing-large-40)' }}>
                    <p style={{ ...headingStyles.small, marginBottom: 'var(--spacing-small-8)' }}>
                      Before you begin
                    </p>
                    <p style={bodyStyles.mediumSecondary}>
                      You only need a few details to get started:
                    </p>
                  </div>

                  {/* Documents List */}
                  <div className="flex flex-col" style={{ gap: 'var(--spacing-medium-24)' }}>
                    {/* Death Certificate */}
                    <div className="flex items-center" style={{ gap: 'var(--spacing-medium-16)' }}>
                      <div className="flex items-center justify-center shrink-0" style={{ background: 'var(--color-surface-bg-information)', padding: 'var(--padding-medium-16)', borderRadius: 'var(--corner-radius-round)' }}>
                        <div className="size-4">
                          <svg className="size-full" fill="none" viewBox="0 0 16 16">
                            <path d={svgPathsDesktop.p2955e500} style={{ fill: 'var(--color-icon-brand-blue)' }} />
                          </svg>
                        </div>
                      </div>
                      <p className="leading-normal" style={bodyStyles.smallSecondary}>
                        Death Certificate
                      </p>
                    </div>

                    {/* Policy Pack and Other Documents */}
                    <div className="flex items-center" style={{ gap: 'var(--spacing-medium-16)' }}>
                      <div className="flex items-center justify-center shrink-0" style={{ background: 'var(--color-surface-bg-information)', padding: 'var(--padding-medium-16)', borderRadius: 'var(--corner-radius-round)' }}>
                        <div className="size-4">
                          <svg className="size-full" fill="none" viewBox="0 0 16 16">
                            <path d={svgPathsDesktop.pf3c9900} style={{ fill: 'var(--color-icon-brand-blue)' }} />
                          </svg>
                        </div>
                      </div>
                      <p className="leading-normal" style={bodyStyles.smallSecondary}>
                        Policy Pack and<br />Other Documents
                      </p>
                    </div>

                    {/* EKYC Documents */}
                    <div className="flex items-center" style={{ gap: 'var(--spacing-medium-16)' }}>
                      <div className="flex items-center justify-center shrink-0" style={{ background: 'var(--color-surface-bg-information)', padding: 'var(--padding-medium-16)', borderRadius: 'var(--corner-radius-round)' }}>
                        <div className="size-4">
                          <svg className="size-full" fill="none" viewBox="0 0 16 16">
                            <path d={svgPathsDesktop.pf3c9900} style={{ fill: 'var(--color-icon-brand-blue)' }} />
                          </svg>
                        </div>
                      </div>
                      <p className="leading-normal" style={bodyStyles.smallSecondary}>
                        EKYC Documents<br />(Yours and Insurer's)
                      </p>
                    </div>
                  </div>

                  {/* Check Shield Watermark */}
                  <div className="absolute w-11 h-11" style={{ left: '391px', top: '99px', opacity: '0.24' }}>
                    <img alt="" className="size-full object-cover" src={imgCheckShield} />
                  </div>

                  {/* Family Image */}
                  <div className="absolute overflow-hidden" style={{ width: '341px', height: '228px', left: '238px', top: '156px', borderRadius: 'var(--corner-radius-16)' }}>
                    <div className="relative" style={{ width: '450px', height: '281px', left: '-53px', top: '-46px' }}>
                      <img alt="Family" className="size-full object-cover" src={imgFamilyDesktop} />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Side - OTP Form */}
            <div className="w-1/2 flex items-center justify-center p-12 relative">
              {/* Back Arrow */}
              <button onClick={onBack} className="absolute left-12 top-12 size-6 shrink-0">
                <svg className="size-full" fill="none" viewBox="0 0 24 24">
                  <path d={svgPathsDesktop.p33fdf300} style={{ fill: 'var(--color-icon-default)' }} />
                </svg>
              </button>

              <div className="w-full max-w-md">
                <OTPInput
                  otpLength={6}
                  variant="inline"
                  device="web"
                  inputType="simpleInput"
                  mobileNumber={parseInt(displayMobile)}
                  value={otp}
                  onChange={(value: string) => setOtp(value)}
                  onButtonClick={handleVerifyOTP}
                  buttonLabel="Verify and Continue"
                />
              </div>
            </div>
          </div>
        ) : (
          // Verifying, Success, Error - Centered Full Screen
          <div className="flex items-center justify-center min-h-screen" style={{ background: 'var(--color-surface-bg-white)' }}>
            <div className="w-full max-w-md">
              {status === 'verifying' && (
                <div className="flex flex-col items-center justify-center" style={{ gap: 'var(--spacing-medium-24)' }}>
                  {/* Loader Ripple */}
                  <LoaderRipple type="primary" size="default" />
                  
                  {/* Message Container */}
                  <div className="flex flex-col items-center justify-center text-center" style={{ gap: 'var(--spacing-small-8)' }}>
                    <h2 style={headingStyles.small}>
                      Verifying your OTP
                    </h2>
                    <p style={bodyStyles.mediumSecondary}>
                      Please do not close or go back<br />from this screen
                    </p>
                  </div>
                </div>
              )}

              {status === 'success' && (
                <div className="flex flex-col items-center justify-center" style={{ gap: 'var(--spacing-medium-24)' }}>
                  {/* Success Icon */}
                  <div className="shrink-0" style={{ width: 'var(--spacing-xtra-large-80)', height: 'var(--spacing-xtra-large-80)' }}>
                    <img alt="Success" className="size-full object-cover" src={imgSuccess} />
                  </div>
                  
                  {/* Message Container */}
                  <div className="flex flex-col items-center justify-center text-center px-4" style={{ gap: 'var(--spacing-small-8)' }}>
                    <h2 style={headingStyles.mediumBold}>
                      Mobile number<br />authenticated!
                    </h2>
                    <p style={bodyStyles.mediumSecondary}>
                      All future communications will be shared on this number
                    </p>
                  </div>
                </div>
              )}

              {status === 'error' && (
                <div className="flex flex-col items-center justify-center px-4" style={{ gap: 'var(--spacing-medium-24)' }}>
                  {/* Error Icon */}
                  <div className="shrink-0" style={{ width: 'var(--padding-large-64)', height: 'var(--padding-large-64)' }}>
                    <svg className="block size-full" fill="none" viewBox="0 0 64 64">
                      <circle cx="32" cy="32" r="32" style={{ fill: 'var(--color-icon-danger)' }} />
                      <path d="M54.471 9.529C60.729 15.884 64.202 24.619 64.154 33.692C64.106 42.765 60.54 51.461 54.209 57.742C47.879 64.024 39.179 67.592 30.103 67.64C21.027 67.688 12.288 64.214 5.933 58.009L54.471 9.529Z" style={{ fill: 'var(--color-button-danger-pressed)' }} />
                      <path d="M35.438 32L45.807 21.643C46.056 21.402 46.254 21.113 46.389 20.794C46.524 20.475 46.593 20.132 46.592 19.785C46.591 19.438 46.521 19.095 46.384 18.776C46.248 18.457 46.048 18.169 45.798 17.929C45.548 17.689 45.253 17.502 44.93 17.38C44.607 17.257 44.263 17.202 43.918 17.217C43.573 17.232 43.235 17.316 42.924 17.465C42.613 17.614 42.336 17.825 42.109 18.086L32 28.172L21.893 18.086C21.422 17.636 20.793 17.387 20.14 17.392C19.487 17.396 18.862 17.654 18.398 18.11C17.935 18.567 17.67 19.188 17.665 19.841C17.66 20.493 17.916 21.118 18.373 21.581L28.732 32L18.373 42.419C18.119 42.663 17.918 42.956 17.782 43.282C17.646 43.608 17.578 43.959 17.581 44.314C17.585 44.668 17.659 45.018 17.801 45.342C17.942 45.666 18.147 45.957 18.404 46.196C18.661 46.436 18.965 46.621 19.296 46.739C19.627 46.857 19.979 46.906 20.331 46.884C20.683 46.862 21.026 46.769 21.341 46.611C21.656 46.453 21.936 46.233 22.164 45.964L32 35.878L41.836 45.964C42.071 46.208 42.354 46.402 42.668 46.534C42.982 46.666 43.32 46.734 43.662 46.733C44.004 46.733 44.342 46.664 44.655 46.53C44.968 46.397 45.251 46.201 45.484 45.955C45.717 45.709 45.896 45.419 46.01 45.102C46.124 44.785 46.171 44.448 46.147 44.112C46.124 43.777 46.031 43.449 45.874 43.151C45.717 42.853 45.499 42.591 45.234 42.381L35.438 32Z" style={{ fill: 'var(--color-icon-white)' }} />
                    </svg>
                  </div>
                  
                  {/* Message Container */}
                  <div className="flex flex-col items-center justify-center text-center" style={{ gap: 'var(--spacing-small-8)' }}>
                    <h2 style={headingStyles.mediumBold}>
                      Mobile number<br />unable to authenticate
                    </h2>
                    <p style={bodyStyles.mediumSecondary}>
                      Please go back and try again
                    </p>
                  </div>

                  {/* Try Again Button */}
                  <Button
                    variant="primary"
                    size="default"
                    onClick={handleTryAgain}
                    className="w-full max-w-xs"
                  >
                    Try Again
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Desktop Footer - Only show when idle */}
        {status === 'idle' && (
          <div className="flex w-full">
            <div className="w-1/2 px-8 py-5" style={{ background: 'var(--gradient-alert-lightInformation)' }}>
              <div className="max-w-lg mx-auto">
                <div className="flex flex-col border px-6 py-4" style={{ background: 'var(--color-surface-bg-white)', borderColor: 'var(--color-border-n100)', borderRadius: 'var(--corner-radius-16)', gap: 'var(--spacing-medium-16)' }}>
                  <p style={bodyStyles.mediumMediumSecondary}>Please note:</p>
                  <div className="flex flex-col" style={{ gap: 'var(--spacing-medium-16)' }}>
                    <div className="flex items-start" style={{ gap: 'var(--spacing-medium-12)' }}>
                      <div className="size-4 shrink-0"><svg className="size-full" fill="none" viewBox="0 0 16 16"><path d={svgPathsNote.p99b6100} style={{ fill: 'var(--color-icon-default)' }} /></svg></div>
                      <p className="leading-normal flex-1" style={bodyStyles.smallSecondary}>The information you share in the claim form will be officially recorded for the policy.</p>
                    </div>
                    <div className="flex items-start" style={{ gap: 'var(--spacing-medium-12)' }}>
                      <div className="size-4 shrink-0"><svg className="size-full" fill="none" viewBox="0 0 16 16"><g clipPath="url(#clip0_2001_6186)"><path d={svgPathsNote.p2d52e3c0} style={{ fill: 'var(--color-icon-default)' }} /></g><defs><clipPath id="clip0_2001_6186"><rect fill="white" height="16" width="16" /></clipPath></defs></svg></div>
                      <p className="leading-normal flex-1" style={bodyStyles.smallSecondary}>Please ensure the information you are sharing is correct.</p>
                    </div>
                    <div className="flex items-start" style={{ gap: 'var(--spacing-medium-12)' }}>
                      <div className="size-4 shrink-0"><svg className="size-full" fill="none" viewBox="0 0 16 16"><path d={svgPathsNote.p2ebf0a00} style={{ fill: 'var(--color-icon-default)' }} /></svg></div>
                      <p className="leading-normal flex-1" style={bodyStyles.smallSecondary}>Our team will never ask you to share the OTP.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="w-1/2 px-8 py-5" style={{ background: 'var(--color-surface-bg-white)' }}>
              <div className="max-w-md mx-auto">
                <div className="flex flex-col px-6 py-4 border" style={{ background: 'var(--color-surface-bg-white)', borderColor: 'var(--color-border-n100)', borderRadius: 'var(--corner-radius-16)', gap: 'var(--spacing-medium-16)' }}>
                  <p className="leading-normal" style={bodyStyles.mediumMediumSecondary}>Providing incorrect or misleading information, whether intentionally or unintentionally can lead to:</p>
                  <div className="flex flex-col" style={{ gap: 'var(--spacing-medium-16)' }}>
                    <div className="flex items-center" style={{ gap: 'var(--spacing-small-8)' }}>
                      <div className="size-6 shrink-0"><svg className="size-full" fill="none" viewBox="0 0 24 24"><path d={svgPathsConsequences.p12a00d80} style={{ fill: 'var(--color-icon-default)' }} /></svg></div>
                      <p className="leading-normal flex-1" style={bodyStyles.smallSecondary}>Delay in Policy Issuance</p>
                    </div>
                    <div className="flex items-center" style={{ gap: 'var(--spacing-small-8)' }}>
                      <div className="size-6 shrink-0"><svg className="size-full" fill="none" viewBox="0 0 24 24"><path d={svgPathsConsequences.p5517f00} style={{ fill: 'var(--color-icon-default)' }} /></svg></div>
                      <p className="leading-normal flex-1" style={bodyStyles.smallSecondary}>Policy Cancellation</p>
                    </div>
                    <div className="flex items-center" style={{ gap: 'var(--spacing-small-8)' }}>
                      <div className="size-6 shrink-0"><svg className="size-full" fill="none" viewBox="0 0 21.1765 21.1765"><path d={svgPathsConsequences.p3a3b6400} style={{ fill: 'var(--color-icon-default)' }} /></svg></div>
                      <p className="leading-normal flex-1" style={bodyStyles.smallSecondary}>Claim Rejection</p>
                    </div>
                    <div className="flex items-center" style={{ gap: 'var(--spacing-small-8)' }}>
                      <div className="size-6 shrink-0"><svg className="size-full" fill="none" viewBox="0 0 21.1765 21.1765"><path d={svgPathsConsequences.p3a3b6400} style={{ fill: 'var(--color-icon-default)' }} /></svg></div>
                      <p className="leading-normal flex-1" style={bodyStyles.smallSecondary}>No third party involvement allowed</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}