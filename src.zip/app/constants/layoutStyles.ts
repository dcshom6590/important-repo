/**
 * Layout Style Constants
 * Reusable inline style objects using Glide Design System tokens
 * Prevents object recreation on re-renders
 */

import { CSSProperties } from 'react';

// Flex Container Styles with Gap
export const flexContainerStyles = {
  // Column layouts
  columnGap16: {
    display: 'flex',
    flexDirection: 'column',
    gap: 'var(--spacing-medium-16)',
  } as CSSProperties,

  columnGap24: {
    display: 'flex',
    flexDirection: 'column',
    gap: 'var(--spacing-medium-24)',
  } as CSSProperties,

  // With margin top
  columnGap16Mt16: {
    marginTop: 'var(--spacing-medium-16)',
    display: 'flex',
    flexDirection: 'column',
    gap: 'var(--spacing-medium-16)',
  } as CSSProperties,
};

// Gap-only Styles (for use with className flex/grid)
export const gapStyles = {
  small4: {
    gap: 'var(--spacing-small-4)',
  } as CSSProperties,

  small8: {
    gap: 'var(--spacing-small-8)',
  } as CSSProperties,

  medium12: {
    gap: 'var(--spacing-medium-12)',
  } as CSSProperties,

  medium16: {
    gap: 'var(--spacing-medium-16)',
  } as CSSProperties,

  medium24: {
    gap: 'var(--spacing-medium-24)',
  } as CSSProperties,
};

// Card/Section Styles
export const cardStyles = {
  white: {
    background: 'var(--color-surface-bg-white)',
    borderRadius: 'var(--corner-radius-8)',
    marginBottom: 'var(--spacing-medium-24)',
    padding: 'var(--padding-medium-24)',
    gap: 'var(--spacing-medium-16)',
  } as CSSProperties,

  whiteFocused: {
    background: 'var(--color-surface-bg-white)',
    boxShadow: 'var(--shadow-focused)',
    borderRadius: 'var(--corner-radius-12)',
    padding: 'var(--padding-medium-20) var(--padding-medium-24)',
  } as CSSProperties,

  whiteFooter: {
    background: 'var(--color-surface-bg-white)',
    borderColor: 'var(--color-border-n100)',
    borderRadius: 'var(--corner-radius-16)',
    gap: 'var(--spacing-medium-16)',
  } as CSSProperties,
};

// Margin Styles
export const marginStyles = {
  bottom24: {
    marginBottom: 'var(--spacing-medium-24)',
  } as CSSProperties,

  bottom40: {
    marginBottom: 'var(--spacing-large-40)',
  } as CSSProperties,

  top16: {
    marginTop: 'var(--spacing-medium-16)',
  } as CSSProperties,

  topBottom24: {
    marginTop: 'var(--spacing-medium-24)',
    marginBottom: 'var(--spacing-medium-24)',
  } as CSSProperties,
};

// Icon Container Styles
export const iconContainerStyles = {
  information: {
    background: 'var(--color-surface-bg-information)',
    padding: 'var(--padding-medium-16)',
    borderRadius: 'var(--corner-radius-round)',
  } as CSSProperties,
};

// Header Styles
export const headerStyles = {
  mobileNav: {
    background: 'var(--color-surface-bg-bold-midnight)',
    boxShadow: 'var(--shadow-flash)',
    borderBottomColor: 'var(--color-border-n100)',
    gap: 'var(--spacing-small-8)',
  } as CSSProperties,
};

// Background Styles
export const backgroundStyles = {
  gradientLightInformation: {
    background: 'var(--gradient-alert-lightInformation)',
  } as CSSProperties,

  white: {
    background: 'var(--color-surface-bg-white)',
  } as CSSProperties,

  boldMidnight: {
    background: 'var(--color-surface-bg-bold-midnight)',
  } as CSSProperties,

  midnight: {
    background: 'var(--color-surface-bg-midnight)',
  } as CSSProperties,
};

// Fixed Bottom CTA Style
export const fixedBottomStyles = {
  cta: {
    background: 'var(--color-surface-bg-white)',
    borderTopColor: 'var(--color-border-mb100)',
  } as CSSProperties,
};

// Stepper Circle Styles
export const stepperStyles = {
  circle: {
    fill: 'var(--color-surface-bg-bold-midnight)',
    stroke: 'var(--color-border-information)',
  } as CSSProperties,
};

// Line/Divider Styles
export const dividerStyles = {
  midnight: {
    background: 'var(--color-surface-bg-midnight)',
  } as CSSProperties,
};
