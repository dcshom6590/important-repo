/**
 * Typography Style Constants
 * Reusable style objects using Glide Design System tokens
 * Prevents object recreation on re-renders
 */

import { CSSProperties } from 'react';

// Heading Styles - Medium Size
export const headingStyles = {
  // Medium size headings
  mediumBold: {
    fontFamily: 'var(--typography-heading-font)',
    fontWeight: 'var(--typography-weight-bold)',
    fontSize: 'var(--typography-heading-size-medium)',
    letterSpacing: 'var(--typography-letter-spacing)',
  } as CSSProperties,

  mediumBoldWithMargin: {
    fontFamily: 'var(--typography-heading-font)',
    fontSize: 'var(--typography-heading-size-medium)',
    color: 'var(--color-text-default)',
    letterSpacing: 'var(--typography-letter-spacing)',
    marginBottom: 'var(--spacing-large-32)',
  } as CSSProperties,

  // Small size headings
  small: {
    fontFamily: 'var(--typography-heading-font)',
    fontWeight: 'var(--typography-weight-bold)',
    fontSize: 'var(--typography-heading-size-small)',
    letterSpacing: 'var(--typography-letter-spacing)',
  } as CSSProperties,
};

// Body Text Styles
export const bodyStyles = {
  small: {
    fontFamily: 'var(--typography-body-font)',
    fontSize: 'var(--typography-body-size-small)',
    color: 'var(--color-text-default)',
  } as CSSProperties,

  smallSecondary: {
    fontFamily: 'var(--typography-body-font)',
    fontSize: 'var(--typography-body-size-small)',
    color: 'var(--color-text-secondary)',
  } as CSSProperties,

  smallWhite: {
    fontFamily: 'var(--typography-body-font)',
    fontSize: 'var(--typography-body-size-small)',
    color: 'var(--color-text-white)',
  } as CSSProperties,

  medium: {
    fontFamily: 'var(--typography-body-font)',
    fontSize: 'var(--typography-body-size-medium)',
    color: 'var(--color-text-default)',
  } as CSSProperties,

  mediumSecondary: {
    fontFamily: 'var(--typography-body-font)',
    fontSize: 'var(--typography-body-size-medium)',
    color: 'var(--color-text-secondary)',
  } as CSSProperties,

  mediumMedium: {
    fontFamily: 'var(--typography-body-font)',
    fontWeight: 'var(--typography-weight-medium)',
    fontSize: 'var(--typography-body-size-medium)',
    color: 'var(--color-text-default)',
  } as CSSProperties,

  mediumMediumSecondary: {
    fontFamily: 'var(--typography-body-font)',
    fontWeight: 'var(--typography-weight-medium)',
    fontSize: 'var(--typography-body-size-medium)',
    color: 'var(--color-text-secondary)',
  } as CSSProperties,

  mediumBold: {
    fontFamily: 'var(--typography-body-font)',
    fontWeight: 'var(--typography-weight-bold)',
    fontSize: 'var(--typography-body-size-medium)',
    color: 'var(--color-text-default)',
  } as CSSProperties,

  mediumBoldBlue: {
    fontFamily: 'var(--typography-body-font)',
    fontWeight: 'var(--typography-weight-bold)',
    fontSize: 'var(--typography-body-size-medium)',
    color: 'var(--color-text-blue)',
  } as CSSProperties,

  smallSemibold: {
    fontFamily: 'var(--typography-body-font)',
    fontWeight: 'var(--typography-weight-semibold)',
    fontSize: 'var(--typography-body-size-small)',
    color: 'var(--color-icon-default)',
  } as CSSProperties,

  smallMediumSecondary: {
    fontFamily: 'var(--typography-body-font)',
    fontWeight: 'var(--typography-weight-medium)',
    fontSize: 'var(--typography-body-size-small)',
    color: 'var(--color-text-default)',
  } as CSSProperties,

  micro: {
    fontFamily: 'var(--typography-body-font)',
    fontSize: 'var(--typography-body-size-micro)',
    color: 'var(--color-text-secondary)',
  } as CSSProperties,

  microBold: {
    fontFamily: 'var(--typography-body-font)',
    fontWeight: 'var(--typography-weight-bold)',
    fontSize: 'var(--typography-body-size-micro)',
    color: 'var(--color-text-white)',
  } as CSSProperties,

  microBoldWhite: {
    fontFamily: 'var(--typography-body-font)',
    fontWeight: 'var(--typography-weight-bold)',
    fontSize: 'var(--typography-body-size-micro)',
    color: 'var(--color-text-white)',
  } as CSSProperties,

  mediumSemibold: {
    fontFamily: 'var(--typography-body-font)',
    fontWeight: 'var(--typography-weight-semibold)',
    fontSize: 'var(--typography-body-size-medium)',
    color: 'var(--color-text-secondary)',
  } as CSSProperties,

  smallSemiboldDefault: {
    fontFamily: 'var(--typography-body-font)',
    fontWeight: 'var(--typography-weight-semibold)',
    fontSize: 'var(--typography-body-size-small)',
    color: 'var(--color-text-default)',
  } as CSSProperties,
};