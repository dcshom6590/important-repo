import { useEffect, useRef, useState } from "react";

const icons = ["💝", "💕", "💘", "💖", "💗", "💓", "💞", "💌"];

const App = () => {
  const noButtonRef = useRef<HTMLButtonElement>(null);
  const [isYes, setIsYes] = useState(false);

  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => {
      if (!noButtonRef.current) return;

      const button = noButtonRef.current;
      const buttonRect = button.getBoundingClientRect();
      const buttonCenterX = buttonRect.left + buttonRect.width / 2;
      const buttonCenterY = buttonRect.top + buttonRect.height / 2;

      const distance = Math.sqrt(
        Math.pow(e.clientX - buttonCenterX, 2) +
          Math.pow(e.clientY - buttonCenterY, 2)
      );

      // If cursor is within 150px of the button
      if (distance < 150) {
        const angle = Math.atan2(
          buttonCenterY - e.clientY,
          buttonCenterX - e.clientX
        );

        const moveDistance = 150 - distance;
        const offsetX = Math.cos(angle) * moveDistance;
        const offsetY = Math.sin(angle) * moveDistance;

        button.style.transform = `translateX(${offsetX}px) translateY(${offsetY}px)`;
      }
    };

    window.addEventListener("mousemove", onMouseMove);

    return () => {
      window.removeEventListener("mousemove", onMouseMove);
    };
  }, []);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen gap-4 min-h-screen w-full bg-gradient-to-br from-[#FFF5F5] via-[#FFFAF0] to-[#FFF0F5] overflow-hidden">
      {isYes ? (
        <>
          <h1
            className="mt-6 text-2xl md:text-3xl font-semibold text-[#FF9AA2] text-center"
            style={{ fontFamily: "Georgia, serif" }}
          >
            YESSS! 🎉
          </h1>
          <img src="/image.jpg" alt="Letter" />
        </>
      ) : (
        <>
          <img src="/letter.svg" alt="Letter" />
          <h1
            className="mt-6 text-2xl md:text-3xl font-semibold text-[#FF9AA2] text-center"
            style={{ fontFamily: "Georgia, serif" }}
          >
            Bablu, will you be my Valentine?
          </h1>
          <div className="flex gap-6 items-center mt-4">
            <button
              className="px-8 py-3 bg-linear-to-r from-[#FFB3BA] to-[#FF9AA2] text-white rounded-full font-medium text-lg shadow-lg hover:shadow-xl transition-shadow hover:scale-110 transition-all duration-300"
              onClick={() => setIsYes(true)}
            >
              Yes 💖
            </button>
            <button
              ref={noButtonRef}
              className="px-8 py-3 bg-gray-100 text-gray-700 rounded-full font-medium text-lg hover:bg-gray-200 shadow-md"
              style={{ transition: "all 0.3s ease-out" }}
            >
              No 🙈
            </button>
          </div>
        </>
      )}

      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {icons.map((icon, index) => (
          <div
            key={index}
            className="absolute text-4xl animate-float"
            style={{
              opacity: 0,
              left: `${Math.random() * 100}%`,
              animationDuration: `${8 + Math.random() * 8}s`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          >
            {icon}
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
